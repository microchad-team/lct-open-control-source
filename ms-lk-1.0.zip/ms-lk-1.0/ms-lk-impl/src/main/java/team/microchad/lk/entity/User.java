package team.microchad.lk.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.validator.constraints.Length;

import java.sql.Date;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@Table(name = "users")
public class User {

    @Id
    Long id;
    @Column
    String name;
    @Column
    String patronymic;
    @Column
    String lastName;
    @Column
    Date birthday;
    @Column
    String businessName;
    @Column
    String ogrn;
    @Column
    @Length(min = 10, max = 10)
    String inn;
    @Column
    @Length(min = 9, max = 9)
    String kpp;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id")
    Auth auth;
}
