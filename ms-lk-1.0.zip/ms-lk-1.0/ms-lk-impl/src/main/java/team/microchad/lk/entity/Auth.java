package team.microchad.lk.entity;


import jakarta.annotation.Nullable;
import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@ToString
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "auth")
public class Auth implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    Long id;
    @Column
    String login;
    @Column
    @Nullable
    String username;
    @Column
    String password;
    @ManyToOne(optional = false)
    @JoinColumn(name = "role")
    Role role;
}
