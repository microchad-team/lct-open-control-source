package team.microchad.lk.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import team.microchad.lk.dto.ControlDto;
import team.microchad.lk.dto.PersonalData;
import team.microchad.lk.dto.UserDto;
import team.microchad.lk.entity.Control;
import team.microchad.lk.entity.User;
import team.microchad.lk.mapper.UserMapper;
import team.microchad.lk.repository.AuthRepository;
import team.microchad.lk.repository.ControlRepository;
import team.microchad.lk.repository.UserRepository;
import team.microchad.lk.service.UserService;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {
    private final UserMapper mapper;
    private final UserRepository userRepository;
    private final ControlRepository controlRepository;
    private final AuthRepository authRepository;


    @Override
    public void updateUser(UserDto userDto) {
        if (authRepository.existsById(userDto.getUserId())) {
            var user = mapper.userDtoToUser(userDto);
            userRepository.save(user);
        }
        else {
            //TODO: make more generic exception
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }

    }

    @Override
    public PersonalData getUser(Long id) {
        var auth = authRepository.findById(id);
        if (auth.isPresent() && auth.get().getRole().getId() == 0) {
            return mapper.userToPersonalData(userRepository.findById(id).orElse(new User()));
        } else if (auth.isPresent() && auth.get().getRole().getId() == 1) {
            return mapper.controlToPersonalData(controlRepository.findById(id).orElse(new Control()));
        }
        else {
            //TODO: make more generic exception
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
    }

    @Override
    public void updateControl(ControlDto controlDto) {
        if (authRepository.existsById(controlDto.getUserId())) {
            var control = mapper.controlDtoToControl(controlDto);
            controlRepository.save(control);
        }
        else {
            //TODO: make more generic exception
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
    }

}
