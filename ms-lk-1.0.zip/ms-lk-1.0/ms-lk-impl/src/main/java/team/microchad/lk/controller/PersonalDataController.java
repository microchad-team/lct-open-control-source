package team.microchad.lk.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import team.microchad.lk.api.UserApi;
import team.microchad.lk.dto.ControlDto;
import team.microchad.lk.dto.PersonalData;
import team.microchad.lk.dto.UserDto;
import team.microchad.lk.service.UserService;

@RestController
@RequiredArgsConstructor
public class PersonalDataController implements UserApi {
    private final UserService userService;

    @Override
    public ResponseEntity<PersonalData> getUser(Long id) {
        return new ResponseEntity<>(userService.getUser(id),
                HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> updateControl(ControlDto controlDto) {
        userService.updateControl(controlDto);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<Void> updateUser(UserDto userDto) {
        userService.updateUser(userDto);
        return ResponseEntity.ok().build();
    }

}
