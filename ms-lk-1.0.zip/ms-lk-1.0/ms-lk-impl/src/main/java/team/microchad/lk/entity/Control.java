package team.microchad.lk.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@Builder
@Table(name = "control")
@AllArgsConstructor
public class Control {
    @Id
    Long id;
    @Column
    String name;
    @Column
    String patronymic;
    @Column
    String lastName;
    @Column
    Long department;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id")
    Auth auth;
}
