package team.microchad.lk.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import team.microchad.calendar.api.DepartmentControllerApi;
import team.microchad.calendar.api.feign.CalendarApiClient;
import team.microchad.calendar.dto.DepartmentDto;
import team.microchad.lk.service.CalendarService;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CalendarServiceImpl implements CalendarService {

    private final CalendarApiClient calendarApiClient;
    public List<DepartmentDto> getDepartmentList() {
        return calendarApiClient.getAllDepartments().getBody();
    }

    public DepartmentDto getDepartmentById(Long id) {
        return calendarApiClient.getDepartmentById(id).getBody();
    }
}
