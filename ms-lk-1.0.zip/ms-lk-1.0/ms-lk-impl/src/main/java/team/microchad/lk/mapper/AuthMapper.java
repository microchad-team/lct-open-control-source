package team.microchad.lk.mapper;

import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import team.microchad.lk.dto.AuthDto;
import team.microchad.lk.dto.RegisterDto;
import team.microchad.lk.entity.Role;
import team.microchad.lk.entity.Auth;

@Mapper(componentModel = "spring", injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public abstract class AuthMapper {
    @Mapping(target = "username", ignore = true)
    @Mapping(target = "id", ignore = true)
    public abstract Auth registerDtoToAuth(RegisterDto registerDto);
    Role map(int value) {
       return new Role(value, null);
    }
}
