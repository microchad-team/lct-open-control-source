package team.microchad.lk.repository;

import org.springframework.data.repository.CrudRepository;
import team.microchad.lk.entity.Auth;
import team.microchad.lk.entity.Control;

public interface ControlRepository extends CrudRepository<Control, Long> {
}