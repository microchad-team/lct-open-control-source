package team.microchad.lk.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import team.microchad.lk.api.AuthApi;
import team.microchad.lk.dto.*;
import team.microchad.lk.service.AuthService;

import java.util.List;

@RestController
@Slf4j
@RequiredArgsConstructor
public class AuthApiController implements AuthApi {
    private final AuthService authService;
    @Override
    public ResponseEntity<SuccessAuthDto> processLogin(LoginRequestDto loginRequestDto) {
        log.info(loginRequestDto.toString());
        return new ResponseEntity<>(
                authService
                .processUserAuth(loginRequestDto),
                HttpStatus.OK
        );
    }

    @Override
    public ResponseEntity<List<AuthDto>> registerBulkProfiles(BulkRegistrationParametersDto bulkRegistrationParametersDto) {
        return new ResponseEntity<>(
                authService.bulkRegistration(bulkRegistrationParametersDto),
                HttpStatus.OK
        );
    }

    @Override
    public ResponseEntity<Void> processRegister(RegisterDto registerDto) {
        log.info(registerDto.toString());
        authService.processUserRegistration(registerDto);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }
}
