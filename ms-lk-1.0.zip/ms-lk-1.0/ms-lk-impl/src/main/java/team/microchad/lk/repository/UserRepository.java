package team.microchad.lk.repository;

import org.springframework.data.repository.CrudRepository;
import team.microchad.lk.entity.User;

public interface UserRepository extends CrudRepository<User, Long> {
}