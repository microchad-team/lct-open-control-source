package team.microchad.lk.mapper;

import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import team.microchad.lk.dto.ControlDto;
import team.microchad.lk.dto.PersonalData;
import team.microchad.lk.dto.UserDto;
import team.microchad.lk.entity.Control;
import team.microchad.lk.entity.User;

@Mapper(componentModel = "spring", injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public abstract class UserMapper {

    @Mapping(target = "id", source = "userId")
    public abstract User userDtoToUser(UserDto user);

    @Mapping(target = "id", source = "userId")
    public abstract Control controlDtoToControl(ControlDto controlDto);

    @Mapping(target = "userId", source = "id")
    public abstract PersonalData userToPersonalData(User user);


    @Mapping(target = "userId", source = "id")
    public abstract PersonalData controlToPersonalData(Control control);
}
