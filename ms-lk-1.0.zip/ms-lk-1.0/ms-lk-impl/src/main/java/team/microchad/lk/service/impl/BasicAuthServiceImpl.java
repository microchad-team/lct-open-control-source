package team.microchad.lk.service.impl;

import com.google.common.hash.Hashing;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import team.microchad.lk.dto.*;
import team.microchad.lk.entity.Auth;
import team.microchad.lk.entity.Control;
import team.microchad.lk.entity.Role;
import team.microchad.lk.exception.WrongCredentialsException;
import team.microchad.lk.mapper.AuthMapper;
import team.microchad.lk.repository.ControlRepository;
import team.microchad.lk.repository.AuthRepository;
import team.microchad.lk.service.AuthService;
import team.microchad.lk.service.CalendarService;
import team.microchad.lk.util.PasswordGenerator;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class BasicAuthServiceImpl implements AuthService {
    private final AuthRepository repository;
    private final AuthMapper mapper;
    private final CalendarService calendarService;
    private final ControlRepository controlRepository;

    @Override
    public SuccessAuthDto processUserAuth(LoginRequestDto requestDto) {
        var user = repository.getUserByLoginAndPassword(requestDto.getLogin(),
                getPasswordHash(requestDto.getPassword()));
        if (user == null) {
            throw new WrongCredentialsException();
        }
        var result = new SuccessAuthDto();
        result.setId(user.getId());
        result.setRole(user.getRole().getTitle());
        result.setUsername(user.getUsername());
        return result;
    }

    @Override
    public void processUserRegistration(RegisterDto registerDto) {
        var user = mapper.registerDtoToAuth(registerDto);
        user.setPassword(
                getPasswordHash(
                        registerDto.getPassword()
                ));
        repository.save(user);
    }

    @Override
    public List<AuthDto> bulkRegistration(BulkRegistrationParametersDto parametersDto) {
        var departmentName = calendarService.getDepartmentById(parametersDto.getDepartment());
        var maxId = repository.maxId() + 1;
        var result = new ArrayList<AuthDto>();
        for (long i = maxId; i < maxId + 10;  i++) {
            Auth auth = generateUserData(departmentName.getTitle(), i);
            var password = auth.getPassword();
            repository.save(getAuthWithHashedPass(auth));
            var control = Control
                    .builder()
                    .id(auth.getId())
                    .auth(auth)
                    .department(parametersDto.getDepartment())
                    .build();
            controlRepository.save(control);
            AuthDto authDto = getAuthDto(auth, password);
            result.add(authDto);
        }
        return result;
    }

    private static AuthDto getAuthDto(Auth auth, String password) {
        var authDto = new AuthDto();
        authDto.setLogin(auth.getLogin());
        authDto.setPassword(password);
        return authDto;
    }

    private Auth getAuthWithHashedPass(Auth auth) {
        auth.setPassword(getPasswordHash(auth.getPassword()));
        return auth;
    }

    private Auth generateUserData(String departmentName, long i) {
        var password = PasswordGenerator.generatePassword();
        var login = departmentName + "_" + i;
        return Auth.builder()
                .login(login)
                .password(password)
                .role(new Role(1, null))
                .build();
    }


    private String getPasswordHash(String password) {
        return Hashing.sha256()
                .hashString(password, StandardCharsets.UTF_8)
                .toString();
    }
}
