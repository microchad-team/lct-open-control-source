package team.microchad.lk.service;

import org.springframework.http.ResponseEntity;
import team.microchad.lk.dto.ControlDto;
import team.microchad.lk.dto.PersonalData;
import team.microchad.lk.dto.UserDto;

public interface UserService {
    void updateUser(UserDto userDto);

    PersonalData getUser(Long id);

    void updateControl(ControlDto controlDto);
}
