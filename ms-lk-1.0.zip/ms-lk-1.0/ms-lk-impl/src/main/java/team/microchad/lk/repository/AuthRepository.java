package team.microchad.lk.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import team.microchad.lk.entity.Auth;

@Repository
public interface AuthRepository extends CrudRepository<Auth, Long> {
    Auth getUserByLoginAndPassword(String login, String password);

    @Query(nativeQuery = true, value = "SELECT max(a.user_id) from auth a")
    Long maxId();
}
