package team.microchad.lk.service;

import team.microchad.calendar.dto.DepartmentDto;

import java.util.List;

public interface CalendarService {
    public List<DepartmentDto> getDepartmentList();
    public DepartmentDto getDepartmentById(Long id);
}
