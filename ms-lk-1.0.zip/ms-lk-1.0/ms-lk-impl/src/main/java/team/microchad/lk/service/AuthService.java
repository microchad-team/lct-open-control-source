package team.microchad.lk.service;

import team.microchad.lk.dto.*;

import java.util.List;

public interface AuthService {
    SuccessAuthDto processUserAuth(LoginRequestDto requestDto);
    void processUserRegistration(RegisterDto registerDto);

    List<AuthDto> bulkRegistration(BulkRegistrationParametersDto parametersDto);
}
