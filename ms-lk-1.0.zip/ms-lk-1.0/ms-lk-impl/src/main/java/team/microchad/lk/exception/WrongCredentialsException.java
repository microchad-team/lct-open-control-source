package team.microchad.lk.exception;

public class WrongCredentialsException extends RuntimeException {
}
