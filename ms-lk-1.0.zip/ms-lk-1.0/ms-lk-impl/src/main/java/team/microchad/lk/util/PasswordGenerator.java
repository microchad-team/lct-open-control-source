package team.microchad.lk.util;

import java.util.Random;

public class PasswordGenerator {
    private static final int PASSWORD_LENGTH = 9;
    private static final String CHARACTERS = "абвгдежзииклмнопрстуфхцчшщъыь";
    private static final Random random = new Random();

    public static String generatePassword() {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < PASSWORD_LENGTH; i++) {
            char c = CHARACTERS.charAt(random.nextInt(CHARACTERS.length()));
            builder.append(c);
        }
        return builder.toString();
    }
}
