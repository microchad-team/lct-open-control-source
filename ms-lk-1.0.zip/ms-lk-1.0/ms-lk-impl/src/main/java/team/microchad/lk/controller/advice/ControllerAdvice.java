package team.microchad.lk.controller.advice;

import jakarta.validation.ConstraintViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import team.microchad.lk.dto.ProcessLogin401Response;
import team.microchad.lk.exception.WrongCredentialsException;


import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.UNAUTHORIZED;

@RestControllerAdvice
public class ControllerAdvice{

    @ExceptionHandler(WrongCredentialsException.class)
    @ResponseStatus(UNAUTHORIZED)
    private ResponseEntity<ProcessLogin401Response> handleWrongCredentials() {
        var response = new ProcessLogin401Response();
        response.setError("Wrong login or password");
        return new ResponseEntity<>(response, UNAUTHORIZED);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseStatus(BAD_REQUEST)
    protected ResponseEntity<String> handleConstraintViolationException(ConstraintViolationException exception) {
        return new ResponseEntity<>(exception.getLocalizedMessage(), BAD_REQUEST);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseStatus(BAD_REQUEST)
    protected ResponseEntity<String> handleInputErrorException() {
        return new ResponseEntity<>("400 Bad request. Check your input", BAD_REQUEST);
    }
}
