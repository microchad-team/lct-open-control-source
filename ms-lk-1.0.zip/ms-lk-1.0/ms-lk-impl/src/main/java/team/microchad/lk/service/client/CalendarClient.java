package team.microchad.lk.service.client;

import org.springframework.cloud.openfeign.FeignClient;
import team.microchad.calendar.api.feign.CalendarApiClient;

@FeignClient(value = "calendar")
public interface CalendarClient extends CalendarApiClient {
}
