﻿using ChatbotMauiClient.Domain.Models;

namespace ChatbotMauiClient.Domain;

public static class MockHelper
{
    public static List<StandardType> StandardTypes = new()
    {
        new StandardType(){ Id=1, Name="Обязательное требование" },
        new StandardType(){ Id=2, Name="Нормативно-правовой акт" },
        new StandardType(){ Id=3, Name="Сервис ГИС" },
    };

    public static List<ControlType> ControlTypes = new()
    {
        new ControlType(){ Id=1, DepartmentId=1, Title="Региональный государственный контроль (надзор) за соблюдением законодательства Российской Федерации и города Москвы об архивном деле в городе Москве" },
        new ControlType(){ Id=2, DepartmentId=2, Title="Региональный государственный контроль за использованием объектов нежилого фонда, находящихся в собственности города Москвы" },
        new ControlType(){ Id=3, DepartmentId=2, Title="Муниципальный земельный контроль на территории города Москвы" },
        new ControlType(){ Id=4, DepartmentId=3, Title="Муниципальный контроль за исполнением единой теплоснабжающей организацией обязательств по строительству, реконструкции и (или) модернизации объектов теплоснабжения на территории города Москвы" },
    };

    public static List<ConsultType> ConsultTypes = new()
    {
        new ConsultType(){ Id=1, ControlId=1, Title="Изучение архива" },
        new ConsultType(){ Id=2, ControlId=1, Title="Обновление архива" },
        new ConsultType(){ Id=3, ControlId=2, Title="Контроль земельных участков" },
        new ConsultType(){ Id=4, ControlId=3, Title="Контроль обязательств" },
    };

    public static List<Department> Departmens = new()
    {
        new Department(){ Id=1, Title="ГЛАВНОЕ АРХИВНОЕ УПРАВЛЕНИЕ ГОРОДА МОСКВЫ" },
        new Department(){ Id=2, Title="ГОСИНСПЕКЦИЯ ПО НЕДВИЖИМОСТИ" },
        new Department(){ Id=3, Title="ДЕПАРТАМЕНТ ЖИЛИЩНО-КОММУНАЛЬНОГО ХОЗЯЙСТВА ГОРОДА МОСКВЫ" },
    };

    public static User ZubenkoKno = new User()
    {
        Id = 1,
        Username = "Зубенко Михаил Петрович",
        UserStatus = "Начальник Государственной инспекции по контролю за использованием объектов недвижимости города Тулы",
        UserDepartment = "ГОСИНСПЕКЦИЯ ПО НЕДВИЖИМОСТИ",
        Role = "admin",
        IsKno = true
    };

    public static User GavrilinUser = new User()
    {
        Id = 2,
        Username = "Гаврилин Альберт Павлович",
        UserStatus = "Индивидуальный предприниматель",
        Role = "user",
        IsKno = false
    };

    public static User UridinUser = new User()
    {
        Id = 3,
        Username = "Юридин Игорь Витальевич",
        UserStatus = "Заместитель начальника",
        UserDepartment = "ООО \"Первый центр образовательных услуг\"",
        Role = "user",
        IsKno = false
    };

    public static User FazilinUser = new User()
    {
        Id = 4,
        Username = "Фазилин Лев Григорьевич",
        UserStatus = "Физическое лицо",
        Role = "user",
        IsKno = false
    };

    private static DateTime GenerateDateTime()
    {
        var now = DateTime.Now;
        var rnd = new Random();
        return now.AddDays(rnd.Next(0, 3))
            .AddHours(rnd.Next(1, 6))
            .AddMinutes(5 * rnd.Next(1,8));
    }

    public static List<Slot> Slots = new()
    {
        new Slot()
        {
            Id = 1,
            Start = GenerateDateTime(),
            Minutes = 45,
            UserName = GavrilinUser.Username,
            UserStatus = GavrilinUser.UserStatus,
            KnoName = ZubenkoKno.Username,
            KnoStatus = ZubenkoKno.UserStatus,
            KnoDepartment = ZubenkoKno.UserDepartment,
            IsApproved = false,
            Description = "Обсуждение по вопросам недвижимости",
            UserId = GavrilinUser.Id,
            KnoId = ZubenkoKno.Id
        },
        new Slot()
        {
            Id = 2,
            Start = GenerateDateTime(),
            Minutes = 120,
            UserName = GavrilinUser.Username,
            UserStatus = GavrilinUser.UserStatus,
            KnoName = ZubenkoKno.Username,
            KnoStatus = ZubenkoKno.UserStatus,
            KnoDepartment = ZubenkoKno.UserDepartment,
            IsApproved = false,
            Description = "Обсуждение по вопросам недвижимости и страховки",
            UserId = GavrilinUser.Id,
            KnoId = ZubenkoKno.Id
        },
        new Slot()
        {
            Id = 3,
            Start = GenerateDateTime(),
            Minutes = 60,
            UserName = FazilinUser.Username,
            UserStatus = FazilinUser.UserStatus,
            KnoName = ZubenkoKno.Username,
            KnoStatus = ZubenkoKno.UserStatus,
            KnoDepartment = ZubenkoKno.UserDepartment,
            IsApproved = false,
            UserId = FazilinUser.Id,
            KnoId = ZubenkoKno.Id
        },
        new Slot()
        {
            Id = 4,
            Start = GenerateDateTime(),
            Minutes = 45,
            UserName = UridinUser.Username,
            UserStatus = UridinUser.UserStatus,
            UserDepartment = UridinUser.UserDepartment,
            KnoName = ZubenkoKno.Username,
            KnoStatus = ZubenkoKno.UserStatus,
            KnoDepartment = ZubenkoKno.UserDepartment,
            IsApproved = false,
            UserId = UridinUser.Id,
            KnoId = ZubenkoKno.Id
        },
        new Slot()
        {
            Id = 5,
            Start = GenerateDateTime(),
            Minutes = 20,
            UserName = UridinUser.Username,
            UserStatus = UridinUser.UserStatus,
            UserDepartment = UridinUser.UserDepartment,
            KnoName = ZubenkoKno.Username,
            KnoStatus = ZubenkoKno.UserStatus,
            KnoDepartment = ZubenkoKno.UserDepartment,
            IsApproved = true,
            UserId = UridinUser.Id,
            KnoId = ZubenkoKno.Id
        },

        new Slot()
        {
            Id = 6,
            Start = GenerateDateTime(),
            Minutes = 45,
            UserName = GavrilinUser.Username,
            UserStatus = GavrilinUser.UserStatus,
            KnoName = ZubenkoKno.Username,
            KnoStatus = ZubenkoKno.UserStatus,
            KnoDepartment = ZubenkoKno.UserDepartment,
            IsApproved = false,
            Description = "Обсуждение по вопросам недвижимости",
            UserId = GavrilinUser.Id,
            KnoId = ZubenkoKno.Id
        },
        new Slot()
        {
            Id = 7,
            Start = GenerateDateTime(),
            Minutes = 120,
            UserName = GavrilinUser.Username,
            UserStatus = GavrilinUser.UserStatus,
            KnoName = ZubenkoKno.Username,
            KnoStatus = ZubenkoKno.UserStatus,
            KnoDepartment = ZubenkoKno.UserDepartment,
            IsApproved = false,
            Description = "Обсуждение по вопросам недвижимости и страховки",
            UserId = GavrilinUser.Id,
            KnoId = ZubenkoKno.Id
        },
        new Slot()
        {
            Id = 8,
            Start = GenerateDateTime(),
            Minutes = 60,
            UserName = FazilinUser.Username,
            UserStatus = FazilinUser.UserStatus,
            KnoName = ZubenkoKno.Username,
            KnoStatus = ZubenkoKno.UserStatus,
            KnoDepartment = ZubenkoKno.UserDepartment,
            IsApproved = false,
            UserId = FazilinUser.Id,
            KnoId = ZubenkoKno.Id
        },
        new Slot()
        {
            Id = 9,
            Start = GenerateDateTime(),
            Minutes = 45,
            UserName = UridinUser.Username,
            UserStatus = UridinUser.UserStatus,
            UserDepartment = UridinUser.UserDepartment,
            KnoName = ZubenkoKno.Username,
            KnoStatus = ZubenkoKno.UserStatus,
            KnoDepartment = ZubenkoKno.UserDepartment,
            IsApproved = false,
            UserId = UridinUser.Id,
            KnoId = ZubenkoKno.Id
        },
        new Slot()
        {
            Id = 10,
            Start = GenerateDateTime(),
            Minutes = 20,
            UserName = UridinUser.Username,
            UserStatus = UridinUser.UserStatus,
            UserDepartment = UridinUser.UserDepartment,
            KnoName = ZubenkoKno.Username,
            KnoStatus = ZubenkoKno.UserStatus,
            KnoDepartment = ZubenkoKno.UserDepartment,
            IsApproved = true,
            UserId = UridinUser.Id,
            KnoId = ZubenkoKno.Id
        }
    };
}
