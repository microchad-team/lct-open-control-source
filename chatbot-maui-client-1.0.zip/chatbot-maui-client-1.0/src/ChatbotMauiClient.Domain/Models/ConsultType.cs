﻿namespace ChatbotMauiClient.Domain.Models;

public class ConsultType
{
    public int Id { get; set; }
    public int ControlId { get; set; }
    public string Title { get; set; }
}
