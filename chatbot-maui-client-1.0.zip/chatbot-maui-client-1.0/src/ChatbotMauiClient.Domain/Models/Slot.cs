﻿namespace ChatbotMauiClient.Domain.Models;

public class Slot
{
    public int Id { get; set; }
    public DateTime Start { get; set; }

    private DateTime end;
    public DateTime End 
    {
        get => end; 
        set
        {
            end = value;
            minutes = Convert.ToInt32((end - Start).TotalMinutes);
        }
    }

    private int minutes;
    public int Minutes
    {
        get => minutes;
        set
        {
            minutes = value;
            end = Start.AddMinutes(minutes);
        }
    }

    public int UserId { get; set; }
    public string UserName { get; set; }
    public string UserStatus { get; set; }
    public string UserDepartment { get; set; }

    public int KnoId { get; set; }
    public string KnoName { get; set; }
    public string KnoStatus { get; set; }
    public string KnoDepartment { get; set; }

    public bool IsApproved { get; set; }
    public string Description { get; set; }
}
