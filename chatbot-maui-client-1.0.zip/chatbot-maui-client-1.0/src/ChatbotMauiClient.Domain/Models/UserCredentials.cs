﻿namespace ChatbotMauiClient.Domain.Models;

public class UserCredentials
{
    public int Id { get; set; }
    public string Login { get; set; }
    public string Password { get; set; }
    public string Username { get; set; }
    public bool IsKno { get; set; }

    public User ToUser()
    {
        return new User()
        {
            Id = Id,
            Username = Username,
            IsKno = IsKno,
            Role = IsKno ? "admin" : "user"
        };
    }
}
