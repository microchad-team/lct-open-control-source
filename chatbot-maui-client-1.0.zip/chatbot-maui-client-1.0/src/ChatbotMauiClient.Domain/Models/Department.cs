﻿namespace ChatbotMauiClient.Domain.Models;

public class Department
{
    public int Id { get; set; }
    public string Title { get; set; }
}
