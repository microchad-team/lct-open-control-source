﻿namespace ChatbotMauiClient.Domain.Models;

public class ControlType
{
    public int Id { get; set; }
    public int DepartmentId { get; set; }
    public string Title { get; set; }
}
