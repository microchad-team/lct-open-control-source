﻿namespace ChatbotMauiClient.Domain.Models;

public class User
{
    public int Id { get; set; }
    public string Username { get; set; }
    public string UserStatus { get; set; }
    public string UserDepartment { get; set; }
    public string Role { get; set; }
    public bool IsKno { get; set; }
}
