﻿using ChatbotMauiClient.Domain;
using ChatbotMauiClient.Pages;
using ChatbotMauiClient.Pages.KnoPages;
using ChatbotMauiClient.Pages.Lk;
using ChatbotMauiClient.Pages.ProfilePages;
using ChatbotMauiClient.Pages.SlotPages;
using ChatbotMauiClient.Services;
using ChatbotMauiClient.ViewModels;

namespace ChatbotMauiClient;

public partial class App : Application
{
	public App()
	{
        InitializeComponent();
        Page appMainPage = new MainPage();
        var userCredentials = AuthService.Instance.GetUserCredentials();
        if (userCredentials != null)
        {
            AuthService.Instance.CurrentUserViewModel = new UserViewModel(userCredentials.ToUser());
            appMainPage = userCredentials.IsKno ? new KnoLkPage() : new UserLkPage();
        }
        MainPage = new NavigationPage(appMainPage);

        //MainPage = new NavigationPage(new KnoMenuPage());
        //MainPage = new NavigationPage(new EditProfilePage());

        // MainPage = new NavigationPage(new ApprovedDocumentsPage());

        //var svm = new SlotViewModel(MockHelper.Slots[3]);
        //MainPage = new NavigationPage(new SlotPage(svm));
    }
}
