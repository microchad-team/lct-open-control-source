﻿public enum ApiType
{
    Auth,
    Chatbot,
    Other
}