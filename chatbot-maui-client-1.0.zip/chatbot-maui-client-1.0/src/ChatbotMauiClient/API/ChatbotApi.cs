﻿using ChatbotMauiClient.API.Requests;
using ChatbotMauiClient.API.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatbotMauiClient.API
{
    public class ChatbotApi : CommonApi
    {
        private static ChatbotApi instance;
        public static ChatbotApi Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new ChatbotApi();
                }
                return instance;
            }
        }

        ChatbotApi() : base() {
            otherUrl = "http://178.170.196.170:8083";
        }

        public async Task<CommonResponse<MessageResponse>> GetInitMessage()
        {
            var response = await SendRequest<MessageResponse>("api/v1/init", HttpMethod.Get, ApiType.Chatbot, "");
            return response;
        }

        public async Task<CommonResponse<MessageResponse>> GetNewMessage(string path)
        {
            return await SendRequest<MessageResponse>(path, HttpMethod.Get, ApiType.Chatbot, "");
        }

        public async Task<CommonResponse<MessageResponse>> PostMessage(MessageRequest messageRequest)
        {
            return await SendRequest<MessageResponse>("api/v1/message", HttpMethod.Post, ApiType.Chatbot, messageRequest);
        }
    }
}
