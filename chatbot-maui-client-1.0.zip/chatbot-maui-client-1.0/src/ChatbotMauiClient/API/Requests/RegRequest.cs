﻿using Newtonsoft.Json;

namespace ChatbotMauiClient.API.Requests;

public class RegRequest
{
    [JsonProperty("login")]
    public string Login { get; set; }

    [JsonProperty("password")]
    public string Password { get; set; }

    [JsonProperty("role")]
    public int Role { get; set; }
}
