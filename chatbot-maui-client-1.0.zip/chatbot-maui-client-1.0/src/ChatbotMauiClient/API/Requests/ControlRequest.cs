﻿using Newtonsoft.Json;

namespace ChatbotMauiClient.API.Requests;

public class ControlRequest
{
    [JsonProperty("department_id")]
    public int DepartmentId { get; set; }
}
