﻿using Newtonsoft.Json;

namespace ChatbotMauiClient.API.Requests;

public class LoginRequest
{
    [JsonProperty("login")]
    public string Login { get; set; }

    [JsonProperty("password")]
    public string Password { get; set; }
}
