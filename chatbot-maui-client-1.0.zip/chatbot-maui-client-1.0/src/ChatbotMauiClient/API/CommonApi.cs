﻿using ChatbotMauiClient.API.Responses;
using Newtonsoft.Json;
using System.Net;
using System.Text;

namespace ChatbotMauiClient.API;

public class CommonApi
{
    protected string baseUrl = "http://localhost:8080";
    
    protected string authUrl = "http://178.170.196.170:8081";
    protected string otherUrl = "http://178.170.196.170:8082/v1";

    //android:usesCleartextTraffic="true"

    protected async Task<CommonResponse<T>> SendRequest<T>(string endpoint, HttpMethod method, ApiType type, object content) where T : class
    {
        try
        {
            using var client = new HttpClient();
            HttpRequestMessage request = new HttpRequestMessage();

            var basePart = (type == ApiType.Auth) ? authUrl : otherUrl;
            request.Method = method;

            var uri = $"{basePart}/{endpoint}"; 
            if (method.Equals(HttpMethod.Get))
            {
                if (content != "")
                {
                    uri += "/" + content;
                }
            }
            else
            {
                string contentRequestJson = JsonConvert.SerializeObject(content);
                request.Content = new StringContent(contentRequestJson, Encoding.UTF8, "application/json");
            }
            request.RequestUri = new Uri(uri);

            HttpResponseMessage response = await client.SendAsync(request);
            if (response.StatusCode == HttpStatusCode.OK || response.StatusCode == HttpStatusCode.Created)
            {
                var contentResponseJson = await response.Content.ReadAsStringAsync();
                var contentResponse = JsonConvert.DeserializeObject<T>(contentResponseJson);
                return new CommonResponse<T>()
                {
                    IsSuccess = true,
                    Response = contentResponse
                };
            }
            Console.WriteLine(response.StatusCode.ToString());
        }
        catch(Exception ex)
        {
            Console.WriteLine(ex.ToString());
        }
        return new CommonResponse<T>();
    }
}
