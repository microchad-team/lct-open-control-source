﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatbotMauiClient.API.Responses
{
    public class MessageResponse
    {
        [JsonProperty("message")]
        public string Message = "";

        [JsonProperty("buttons")]
        public List<ChatbotButton> Buttons = new();
    }
}
