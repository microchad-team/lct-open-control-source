﻿using Newtonsoft.Json;

namespace ChatbotMauiClient.API.Responses.Models;

public class ControlModel
{
    [JsonProperty("id")]
    public int Id { get; set; }

    [JsonProperty("name")]
    public string Title { get; set; }
}
