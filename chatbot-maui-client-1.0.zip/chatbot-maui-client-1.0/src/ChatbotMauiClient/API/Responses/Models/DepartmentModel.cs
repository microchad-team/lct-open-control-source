﻿using Newtonsoft.Json;

namespace ChatbotMauiClient.API.Responses.Models;

public class DepartmentModel
{
    [JsonProperty("id")]
    public int Id { get; set; }

    [JsonProperty("departmentName")]
    public string Title { get; set; }
}
