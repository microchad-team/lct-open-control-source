﻿using ChatbotMauiClient.API.Responses.Models;
using Newtonsoft.Json;

namespace ChatbotMauiClient.API.Responses;

public class DepartmentResponse
{
    [JsonProperty("departments")]
    public List<DepartmentModel> Departments { get; set; }
}
