﻿namespace ChatbotMauiClient.API.Responses;

public class CommonResponse<T> where T : class
{
    public T Response { get; set; } = null;

    public bool IsSuccess { get; set; } = false;
}
