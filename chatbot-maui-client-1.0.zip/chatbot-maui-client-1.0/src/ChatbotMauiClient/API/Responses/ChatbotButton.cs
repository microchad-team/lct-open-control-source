﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatbotMauiClient.API.Responses
{
    public class ChatbotButton
    {
        [JsonProperty("buttonId")]
        public int ButtonId { get; set; }

        [JsonProperty("text")]
        public string Text { get; set; }

        [JsonProperty("action")]
        public Action Action { get; set; }
    }
}

