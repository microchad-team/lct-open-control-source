﻿using ChatbotMauiClient.API.Responses.Models;
using Newtonsoft.Json;

namespace ChatbotMauiClient.API.Responses;

public class ControlResponse
{
    [JsonProperty("controls")]
    public List<ControlModel> Controls { get; set; }
}
