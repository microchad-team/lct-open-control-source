﻿using Newtonsoft.Json;

namespace ChatbotMauiClient.API.Responses;

public class LoginResponse
{
    [JsonProperty("id")]
    public int Id { get; set; }

    [JsonProperty("username")]
    public string Username { get; set; }

    [JsonProperty("userstatus")]
    public string UserStatus { get; set; }

    [JsonProperty("userdepartment")]
    public string UserDepartment { get; set; }

    [JsonProperty("role")]
    public string Role { get; set; }
}
