﻿namespace ChatbotMauiClient.API.Responses;

public class RegResponse
{
}
