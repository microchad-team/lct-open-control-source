﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatbotMauiClient.API.Responses
{
    public class Action
    {
        [JsonProperty("actionType")]
        public int ActionType { get; set; }

        [JsonProperty("action")]
        public string ActionLink { get; set; }
    }
}
