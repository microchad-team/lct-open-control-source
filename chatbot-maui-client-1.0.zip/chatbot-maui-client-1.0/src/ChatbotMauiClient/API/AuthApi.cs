﻿using ChatbotMauiClient.API.Requests;
using ChatbotMauiClient.API.Responses;
using ChatbotMauiClient.Domain;

namespace ChatbotMauiClient.API;

public class AuthApi : CommonApi
{
    private static AuthApi instance;
    public static AuthApi Instance
    {
        get
        {
            if (instance == null)
            {
                instance = new AuthApi();
            }
            return instance;
        }
    }

    private AuthApi() { }

    public async Task<CommonResponse<LoginResponse>> Login(string login, string password)
    {
        if(MauiProgram.Mock)
        {
            var user = login == "admin" ? MockHelper.ZubenkoKno : MockHelper.GavrilinUser;
            return new CommonResponse<LoginResponse>()
            {
                Response = new LoginResponse() 
                {
                    Id = user.Id,
                    Username = user.Username,
                    UserStatus = user.UserStatus,
                    UserDepartment = user.UserDepartment,
                    Role = user.Role
                },
                IsSuccess = true
            };
        }
        var loginRequest = new LoginRequest() { Login = login, Password = password };
        return await SendRequest<LoginResponse>("login", HttpMethod.Post, ApiType.Auth, loginRequest);
    }

    public async Task<CommonResponse<RegResponse>> Register(string login, string password)
    {
        if (MauiProgram.Mock)
        {
            return new CommonResponse<RegResponse>()
            {
                Response = new RegResponse(),
                IsSuccess = true
            };
        }
        var regRequest = new RegRequest() { Login = login, Password = password, Role=0 };
        return await SendRequest<RegResponse>("register", HttpMethod.Post, ApiType.Auth, regRequest);
    }
}
