﻿using ChatbotMauiClient.API.Requests;
using ChatbotMauiClient.API.Responses;
using ChatbotMauiClient.Domain;
using ChatbotMauiClient.API.Responses.Models;

namespace ChatbotMauiClient.API;

public class ControlApi : CommonApi
{
    private static ControlApi instance;
    public static ControlApi Instance
    {
        get
        {
            if (instance == null)
            {
                instance = new ControlApi();
            }
            return instance;
        }
    }
    private ControlApi() { }

    public async Task<CommonResponse<IEnumerable<ControlModel>>> GetControls(int id)
    {
        return await SendRequest<IEnumerable<ControlModel>>("control_type", HttpMethod.Get, ApiType.Other, id);
    }

    public async Task<CommonResponse<IEnumerable<DepartmentModel>>> GetDepartments()
    {
        return await SendRequest<IEnumerable<DepartmentModel>>("department", HttpMethod.Get, ApiType.Other, "");
    }

    public async Task<CommonResponse<IEnumerable<ThemeModel>>> GetThemes(int id)
    {
        return await SendRequest<IEnumerable<ThemeModel>>("theme", HttpMethod.Get, ApiType.Other, id);
    }
}
