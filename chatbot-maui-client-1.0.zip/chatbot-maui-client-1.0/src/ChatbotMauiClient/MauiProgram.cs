﻿#if ANDROID
using ChatbotMauiClient.Platforms.Android;
#endif
using ChatbotMauiClient.Services;
using CommunityToolkit.Maui;
using CommunityToolkit.Maui.Storage;
using Microsoft.Maui.Controls.PlatformConfiguration;

namespace ChatbotMauiClient;

public static class MauiProgram
{
	public static bool Mock = true;

	public static MauiApp CreateMauiApp()
	{
#if ANDROID
			DangerousAndroidMessageHandlerEmitter.Register();
			DangerousTrustProvider.Register();
#endif

		Microsoft.Maui.Handlers.EditorHandler.Mapper.AppendToMapping("EditorCustomization", (handler, view) =>
		{
#if ANDROID
			handler.PlatformView.SetPadding(30, 30, 30, 30); 
			 handler.PlatformView.SetBackgroundColor(Android.Graphics.Color.Transparent);
#endif
        });
		Microsoft.Maui.Handlers.PickerHandler.Mapper.AppendToMapping("PickerCustomization", (handler, view) =>
		{
#if ANDROID
handler.PlatformView.SetPadding(30, 30, 30, 30); 
                handler.PlatformView.SetBackgroundColor(Android.Graphics.Color.Argb(255, 249, 249, 249));
#endif
        });


		Microsoft.Maui.Handlers.EntryHandler.Mapper.AppendToMapping("MyCustomization", (handler, view) =>
        {
           
            if (view is Entry)
            {
#if ANDROID
					handler.PlatformView.SetPadding(30, 30, 30, 30); 
					handler.PlatformView.SetBackgroundColor(Android.Graphics.Color.Argb(255, 255, 245, 242));
#endif
            }
        });

		var builder = MauiApp.CreateBuilder();
		builder
			.UseMauiApp<App>()
			.UseMauiCommunityToolkit()
			.ConfigureFonts(fonts =>
			{
				fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
				fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
			});
        return builder.Build();
	}
}
