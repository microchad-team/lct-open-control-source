﻿using ChatbotMauiClient.Domain.Models;
using System.Xml.Linq;

namespace ChatbotMauiClient.ViewModels;

public class UserViewModel : NotifyModel
{
    private int id;
    public int Id
    {
        get => id;
        set
        {
            if (id != value)
            {
                id = value;
                OnPropertyChanged("Id");
            }
        }
    }

    private string username;
    public string Username
    {
        get => username;
        set
        {
            if (username != value)
            {
                username = value;
                OnPropertyChanged("Username");
            }
        }
    }

    private string userStatus;
    public string UserStatus
    {
        get => userStatus;
        set
        {
            if (userStatus != value)
            {
                userStatus = value;
                OnPropertyChanged("UserStatus");
            }
        }
    }

    private string userDepartment;
    public string UserDepartment
    {
        get => userDepartment;
        set
        {
            if (userDepartment != value)
            {
                userDepartment = value;
                OnPropertyChanged("UserDepartment");
                OnPropertyChanged("IsUserDepartmentExist");
            }
        }
    }

    public bool IsUserDepartmentExist
    {
        get => !string.IsNullOrWhiteSpace(userDepartment);

    }

    private string role;
    public string Role
    {
        get => role;
        set
        {
            if (role != value)
            {
                role = value;
                OnPropertyChanged("Role");
            }
        }
    }

    private bool isKno;
    public bool IsKno
    {
        get => isKno;
        set
        {
            if (isKno != value)
            {
                isKno = value;
                OnPropertyChanged("IsKno");
            }
        }
    }

    public User User { get; set; }

    public UserViewModel(User user)
    {
        User = user;
        Id = user.Id;
        Username = user.Username;
        UserStatus = user.UserStatus;
        UserDepartment = user.UserDepartment;
        Role = user.Role;
        IsKno = user.IsKno;
    }
}
