﻿using ChatbotMauiClient.Domain.Models;

namespace ChatbotMauiClient.ViewModels;

public class SlotViewModel : NotifyModel
{
    private int id;
    public int Id
    {
        get => id;
        set
        {
            if (id != value)
            {
                id = value;
                OnPropertyChanged("Id");
            }
        }
    }


    private int userId;
    public int UserId
    {
        get => userId;
        set
        {
            if (userId != value)
            {
                userId = value;
                OnPropertyChanged("UserId");
            }
        }
    }


    private int knoId;
    public int KnoId
    {
        get => knoId;
        set
        {
            if (knoId != value)
            {
                knoId = value;
                OnPropertyChanged("KnoId");
            }
        }
    }

    private DateTime start;
    public DateTime Start
    {
        get => start;
        set
        {
            if (start != value)
            {
                start = value;
                OnPropertyChanged("Start");
            }
        }
    }

    private DateTime end;
    public DateTime End
    {
        get => end;
        set
        {
            end = value;
            minutes = (end - Start).Minutes;
            OnPropertyChanged("End");
            OnPropertyChanged("Minutes");
        }
    }

    private int minutes;
    public int Minutes
    {
        get => minutes;
        set
        {
            minutes = value;
            end = Start.AddMinutes(minutes);
            OnPropertyChanged("End");
            OnPropertyChanged("Minutes");
        }
    }

    private string userName;
    public string UserName
    {
        get => userName;
        set
        {
            if (userName != value)
            {
                userName = value;
                OnPropertyChanged("UserName");
            }
        }
    }

    private string userStatus;
    public string UserStatus
    {
        get => userStatus;
        set
        {
            if (userStatus != value)
            {
                userStatus = value;
                OnPropertyChanged("UserStatus");
            }
        }
    }

    private string userDepartment;
    public string UserDepartment
    {
        get => userDepartment;
        set
        {
            if (userDepartment != value)
            {
                userDepartment = value;
                OnPropertyChanged("UserDepartment");
                OnPropertyChanged("IsUserDepartmentExist");
                OnPropertyChanged("IsUserDepartmentNonExist");
            }
        }
    }

    private string knoName;
    public string KnoName
    {
        get => knoName;
        set
        {
            if (knoName != value)
            {
                knoName = value;
                OnPropertyChanged("KnoName");
            }
        }
    }

    private string knoStatus;
    public string KnoStatus
    {
        get => knoStatus;
        set
        {
            if (knoStatus != value)
            {
                knoStatus = value;
                OnPropertyChanged("KnoStatus");
            }
        }
    }

    private string knoDepartment;
    public string KnoDepartment
    {
        get => knoDepartment;
        set
        {
            if (knoDepartment != value)
            {
                knoDepartment = value;
                OnPropertyChanged("KnoDepartment");
            }
        }
    }

    private string description;
    public string Description
    {
        get => description;
        set
        {
            if (description != value)
            {
                description = value;
                OnPropertyChanged("Description");
                OnPropertyChanged("IsDescriptionExist"); 
            }
        }
    }

    private bool isApproved;
    public bool IsApproved
    {
        get => isApproved;
        set
        {
            if (isApproved != value)
            {
                isApproved = value;
                OnPropertyChanged("IsApproved");
                OnPropertyChanged("IsNotApproved");
            }
        }
    }

    public string Date
    {
        get => Start.Date.ToString("dd.MM.yyyy (dddd)");
    }

    public string TimeSpan
    {
        get => $"{Start.ToString("HH:mm")} - {End.ToString("HH:mm")} ({(End-Start).TotalMinutes} мин)";
    }

    public bool IsNotApproved
    {
        get => !IsApproved;
    }

    public bool IsDescriptionExist
    {
        get => !string.IsNullOrWhiteSpace(Description);
    }

    public bool IsUserDepartmentExist
    {
        get => !string.IsNullOrWhiteSpace(UserDepartment);
    }

    public bool IsUserDepartmentNonExist
    {
        get => !IsUserDepartmentExist;
    }

    public bool IsStartToday
    {
        get => Start.Date.Equals(DateTime.Now.Date);
    }

    public Slot Slot { get; set; }

    public SlotViewModel(Slot slot)
    {
        Slot = slot;
        Id = slot.Id;
        Start = slot.Start;
        End = slot.End;
        Minutes = slot.Minutes;
        UserName = slot.UserName;
        UserStatus = slot.UserStatus;
        UserDepartment = slot.UserDepartment;
        KnoName = slot.KnoName;
        KnoStatus = slot.KnoStatus;
        KnoDepartment = slot.KnoDepartment;
        IsApproved = slot.IsApproved;
        Description = slot.Description;
        UserId = slot.UserId;
        KnoId = slot.KnoId;
    }
}