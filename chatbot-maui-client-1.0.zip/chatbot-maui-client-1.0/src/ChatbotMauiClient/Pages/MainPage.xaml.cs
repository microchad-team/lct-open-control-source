﻿namespace ChatbotMauiClient.Pages;

public partial class MainPage : TabbedPage
{
	public MainPage()
	{
        NavigationPage.SetHasBackButton(this, false);
        InitializeComponent();
	}
}

