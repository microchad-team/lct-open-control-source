using ChatbotMauiClient.Services;
using Microsoft.Extensions.Logging.Abstractions;
using System;

namespace ChatbotMauiClient.Pages.ProfilePages;

public partial class EditProfilePage : ContentPage
{
    public EditProfilePage()
	{
        NavigationPage.SetHasNavigationBar(this, false);
        BindingContext = AuthService.Instance.CurrentUserViewModel;
        InitializeComponent();
    }

    private void MenuClicked(object sender, EventArgs e)
    {
        UnfocusEntries();
        (Parent.Parent as FlyoutPage).IsPresented = true;
    }

    private void Editor_Unfocused(object sender, FocusEventArgs e)
    {
        AuthService.Instance.CurrentUserViewModel.UserStatus = System.Text.RegularExpressions.Regex.Replace((sender as Editor).Text.Trim(), @"\s+", " ");
    }

    private void UsernameEntry_Unfocused(object sender, FocusEventArgs e)
    {
        AuthService.Instance.CurrentUserViewModel.Username = System.Text.RegularExpressions.Regex.Replace((sender as Entry).Text.Trim(), @"\s+", " ");
    }

    public void UnfocusEventHandler(object source, EventArgs e)
    {
        UnfocusEntries();
    }

    public void UnfocusEntries()
    {
        if(UsernameEntry!=null)
        {
            UsernameEntry.IsEnabled = false;
            UsernameEntry.IsEnabled = true;
            UsernameEntry.Unfocus();
        }
        if (UsernameEntry != null)
        {
            UserStatusEditor.IsEnabled = false;
            UserStatusEditor.IsEnabled = true;
            UserStatusEditor.Unfocus();
        }
    }

    private void ContentPage_Appearing(object sender, EventArgs e)
    {
        if (Parent.Parent is FlyoutPage)
        {
            (Parent.Parent as FlyoutPage).IsPresentedChanged += UnfocusEventHandler;
        }
    }

    private void ContentPage_Disappearing(object sender, EventArgs e)
    {
        if(Parent.Parent is FlyoutPage) 
        {
            (Parent.Parent as FlyoutPage).IsPresentedChanged -= UnfocusEventHandler;
        }
    }
}