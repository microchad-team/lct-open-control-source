using ChatbotMauiClient.Pages.LayoutModels;
using ChatbotMauiClient.Services;

namespace ChatbotMauiClient.Pages.Lk;

public partial class KnoLkPage : FlyoutPage
{
    public KnoLkPage()
	{
        NavigationPage.SetHasBackButton(this, false);
        InitializeComponent();
        flyoutMenu.listview.ItemSelected += OnSelectedItem;
        flyoutMenu.listviewOther.ItemSelected += OnSelectedItem;
        flyoutMenu.listviewProfile.ItemSelected += OnSelectedItem;
        IsPresented = true;
    }

    private void OnSelectedItem(object sender, SelectedItemChangedEventArgs e)
    {
        var item = e.SelectedItem as FlyoutItemPage;
        if(item != null)
        {
            Detail = new NavigationPage((Page)Activator.CreateInstance(item.TargetPage));
            flyoutMenu.listview.SelectedItem = null;
            flyoutMenu.listviewOther.SelectedItem = null;
            flyoutMenu.listviewProfile.SelectedItem = null;
            IsPresented = false;
        }
    }

    private void MenuButton_Clicked(object sender, EventArgs e)
    {
        IsPresented = true;
    }

    protected override bool OnBackButtonPressed()
    {
        return true;
    }
}