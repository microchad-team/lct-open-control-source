using ChatbotMauiClient.Pages.LayoutModels;

namespace ChatbotMauiClient.Pages.Lk;

public partial class UserLkPage : FlyoutPage
{
    public UserLkPage()
    {
        NavigationPage.SetHasBackButton(this, false);
        InitializeComponent();
        flyoutMenu.listview.ItemSelected += OnSelectedItem;
        flyoutMenu.listviewSchedule.ItemSelected += OnSelectedItem;
        flyoutMenu.listviewProfile.ItemSelected += OnSelectedItem;
        IsPresented = true;
    }

    private void OnSelectedItem(object sender, SelectedItemChangedEventArgs e)
    {
        var item = e.SelectedItem as FlyoutItemPage;
        if (item != null)
        {
            Detail = new NavigationPage((Page)Activator.CreateInstance(item.TargetPage));
            flyoutMenu.listview.SelectedItem = null;
            flyoutMenu.listviewSchedule.SelectedItem = null;
            flyoutMenu.listviewProfile.SelectedItem = null;
            IsPresented = false;
        }
    }

    private void MenuButton_Clicked(object sender, EventArgs e)
    {
        IsPresented = true;
    }

    protected override bool OnBackButtonPressed()
    {
        return true;
    }
}