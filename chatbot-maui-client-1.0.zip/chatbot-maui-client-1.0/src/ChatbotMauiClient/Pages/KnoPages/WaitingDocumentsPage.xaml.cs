using ChatbotMauiClient.Domain;
using ChatbotMauiClient.Domain.Models;
using ChatbotMauiClient.Pages.SlotPages;
using ChatbotMauiClient.ViewModels;
using System.Linq;

namespace ChatbotMauiClient.Pages.KnoPages;

public partial class WaitingDocumentsPage : ContentPage
{
    public WaitingDocumentsPage()
    {
        NavigationPage.SetHasNavigationBar(this, false);
        InitializeComponent();
    }

    private void MenuClicked(object sender, EventArgs e)
    {
        (Parent.Parent as FlyoutPage).IsPresented = true;
    }

    private async void WaitingDocumentTapped(object sender, ItemTappedEventArgs e)
    {
        var item = (sender as ListView).SelectedItem as SlotViewModel;
        if (item != null)
        {
            (sender as ListView).SelectedItem = null;
            await Navigation.PushAsync(new SlotPage(item, true));
        }
    }

    private void ApproveButton_Clicked(object sender, EventArgs e)
    {
        var svm = (sender as Button).BindingContext as SlotViewModel;
        MockHelper.Slots.FirstOrDefault(s => s.Id == svm.Id).IsApproved = true;
        var slots = MockHelper.Slots.Select(s => new SlotViewModel(s));
        BindingContext = slots.Where(s => s.Id != svm.Id && s.IsNotApproved);
    }

    private void ContentPage_Appearing(object sender, EventArgs e)
    {
        var svms = MockHelper.Slots.Where(s => !s.IsApproved).Select(slot => new SlotViewModel(slot));
        BindingContext = svms;
    }
}