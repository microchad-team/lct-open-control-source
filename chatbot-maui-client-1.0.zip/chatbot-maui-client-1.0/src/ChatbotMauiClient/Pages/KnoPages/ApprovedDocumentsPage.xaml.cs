using ChatbotMauiClient.Domain;
using ChatbotMauiClient.Pages.SlotPages;
using ChatbotMauiClient.ViewModels;

namespace ChatbotMauiClient.Pages.KnoPages;

public partial class ApprovedDocumentsPage : ContentPage
{
    private bool isFilterClicked;

    public ApprovedDocumentsPage()
    {
        NavigationPage.SetHasNavigationBar(this, false);
        InitializeComponent();
        var svms = MockHelper.Slots.Select(slot => new SlotViewModel(slot)).Where(s => s.IsApproved);
        BindingContext = svms;
        DatePicker.MinimumDate = DateTime.Now;
    }

    private void MenuClicked(object sender, EventArgs e)
    {
        (Parent.Parent as FlyoutPage).IsPresented = true;
    }

    private void FilterClicked(object sender, EventArgs e)
    {
        isFilterClicked = !isFilterClicked;
        Filter.Source = isFilterClicked ? "filter.png" : "filter_unactive.png";
        Filters.IsVisible = isFilterClicked;
        if (!isFilterClicked)
        {
            var svms = MockHelper.Slots.Select(slot => new SlotViewModel(slot)).Where(s => s.IsApproved);
            BindingContext = svms;
        }
        else
        {
            var svms = MockHelper.Slots
                .Select(slot => new SlotViewModel(slot))
                .Where(slot => slot.Start.Date.Equals(DatePicker.Date.Date))
                .Where(s => s.IsApproved);
            BindingContext = svms;
        }
    }

    private async void ApprovedDocumentTapped(object sender, ItemTappedEventArgs e)
    {
        var item = (sender as ListView).SelectedItem as SlotViewModel;
        if (item != null)
        {
            (sender as ListView).SelectedItem = null;
            await Navigation.PushAsync(new SlotPage(item, false));
        }
    }

    private void DatePicker_DateSelected(object sender, DateChangedEventArgs e)
    {
        var svms = MockHelper.Slots
            .Select(slot => new SlotViewModel(slot))
            .Where(slot => slot.Start.Date.Equals(e.NewDate.Date))
            .Where(s => s.IsApproved);
        BindingContext = svms;
    }
}