namespace ChatbotMauiClient.Pages.KnoPages;

public partial class UpdateScheduleSlotsPage : ContentPage
{
    public UpdateScheduleSlotsPage()
    {
        NavigationPage.SetHasNavigationBar(this, false);
        InitializeComponent();
    }

    private void MenuClicked(object sender, EventArgs e)
    {
        (Parent.Parent as FlyoutPage).IsPresented = true;
    }
}