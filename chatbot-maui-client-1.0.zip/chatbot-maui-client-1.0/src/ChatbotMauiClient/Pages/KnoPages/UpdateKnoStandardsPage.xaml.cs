using ChatbotMauiClient.Domain;
using ChatbotMauiClient.Domain.Models;

namespace ChatbotMauiClient.Pages.KnoPages;

public partial class UpdateKnoStandardsPage : ContentPage
{
	public UpdateKnoStandardsPage()
	{
        NavigationPage.SetHasNavigationBar(this, false);
        InitializeComponent();
        ControlTypesPicker.ItemsSource = MockHelper.StandardTypes;
    }

    private void MenuClicked(object sender, EventArgs e)
    {
        (Parent.Parent as FlyoutPage).IsPresented = true;
    }

    private ControlType SelectedControlType;
    private string FileName;
    private string FilePath;

    private void ControlTypesPicker_SelectedIndexChanged(object sender, EventArgs e)
    {
        var item = (sender as Picker)?.SelectedItem;
        if (item != null)
        {
            UploadFromDeviceButton.IsVisible = true;
            SelectedControlType = item as ControlType;
        }
    }

    private async void UploadFromDeviceButton_Clicked(object sender, EventArgs e)
    {
        var customFileTypes = new FilePickerFileType(new Dictionary<DevicePlatform, IEnumerable<string>>
        {
            {
                DevicePlatform.Android, new[]
                {
                    "application/vnd.ms-excel",
                    "application/vnd.ms-excel.sheet.binary.macroenabled.12",
                    "application/vnd.ms-excel.sheet.macroenabled.12",
                    "application/vnd.ms-excel.template.macroenabled.12",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.template"
                }
            }
        });

        var result = await FilePicker.PickAsync(new PickOptions
        {
            PickerTitle = "�������� ���� Excel",
            FileTypes = customFileTypes
        });

        if (result == null)
            return;

        FileName = result.FileName;
        FilePath = result.FullPath;
        UploadButton.Text = $"��������� ���� \"{result.FileName}\"";
        UploadButton.IsVisible = true;
    }


    private async void UploadButton_Clicked(object sender, EventArgs e)
    {
        var s = SelectedControlType;
        var f = FileName;
    }
}