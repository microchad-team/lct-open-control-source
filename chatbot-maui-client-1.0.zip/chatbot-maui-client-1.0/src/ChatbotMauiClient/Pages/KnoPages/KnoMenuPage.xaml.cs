using ChatbotMauiClient.Domain;
using ChatbotMauiClient.Pages.LayoutModels;
using ChatbotMauiClient.Pages.ProfilePages;
using ChatbotMauiClient.Services;

namespace ChatbotMauiClient.Pages.KnoPages;

public partial class KnoMenuPage : ContentPage
{
	public KnoMenuPage()
	{
        BindingContext = AuthService.Instance.CurrentUserViewModel;
        NavigationPage.SetHasBackButton(this, false);
        InitializeComponent();
    }

    private void LogOut(object sender, EventArgs e)
    {
        AuthService.Instance.LogOut();
    }

    private void GoToEditProfilePage(object sender, EventArgs e)
    {
        (Parent as FlyoutPage).Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(EditProfilePage)));
    }

    public void AppearedEventHandler(object source, EventArgs e)
    {
        listview.ItemsSource = new List<FlyoutItemPage>()
        {
            new FlyoutItemPage()
            {
                Title="������������� ������",
                IconSource="confirmed_document.png",
                Color="DarkGray",
                TargetPage=typeof(ApprovedDocumentsPage),
                WithNotifications=true,
                NotificationCounter = MockHelper.Slots.Count(s => s.IsApproved)
            },
            new FlyoutItemPage()
            {
                Title="������� �������������",
                IconSource="waiting_document.png",
                Color="#F64027",
                TargetPage=typeof(WaitingDocumentsPage),
                WithNotifications=true,
                NotificationCounter = MockHelper.Slots.Count(s => !s.IsApproved)
            }
        };
    }

    private void ContentPage_Appearing(object sender, EventArgs e)
    {
        (Parent as FlyoutPage).IsPresentedChanged += AppearedEventHandler;
        AppearedEventHandler(null, null);
    }
}