namespace ChatbotMauiClient.Pages.UserPages;

public partial class ConsultingCalendarPage : ContentPage
{
	public ConsultingCalendarPage()
	{
        NavigationPage.SetHasNavigationBar(this, false);
        InitializeComponent();
	}

    private async void BackButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }
}