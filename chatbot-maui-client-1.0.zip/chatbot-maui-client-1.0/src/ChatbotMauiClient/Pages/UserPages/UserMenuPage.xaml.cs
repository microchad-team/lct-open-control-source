using ChatbotMauiClient.Domain;
using ChatbotMauiClient.Pages.LayoutModels;
using ChatbotMauiClient.Pages.ProfilePages;
using ChatbotMauiClient.Services;

namespace ChatbotMauiClient.Pages.UserPages;

public partial class UserMenuPage : ContentPage
{
	public UserMenuPage()
	{
        BindingContext = AuthService.Instance.CurrentUserViewModel;
        NavigationPage.SetHasNavigationBar(this, false);
        InitializeComponent();

        listview.ItemsSource = new List<FlyoutItemPage>()
        {
            new FlyoutItemPage()
            {
                Title="���-���",
                IconSource="chat_bot.png",
                TargetPage=typeof(ChatbotPage),
                WithNotifications=false
            },
            new FlyoutItemPage()
            {
                Title="����������",
                IconSource="edit_document.png",
                TargetPage=typeof(ConsultingPage),
                WithNotifications=false
            }
        };

        listviewSchedule.ItemsSource = new List<FlyoutItemPage>()
        {
            new FlyoutItemPage()
            {
                Title="���� ������",
                IconSource="confirmed_document.png",
                Color="DarkGray",
                TargetPage=typeof(UserDocumentsPage),
                WithNotifications=true,
                NotificationCounter = MockHelper.Slots.Count(s => s.UserId == AuthService.Instance.CurrentUserViewModel.Id)
            }
        };
    }

    private void LogOut(object sender, EventArgs e)
    {
        AuthService.Instance.LogOut();
    }

    private void GoToEditProfilePage(object sender, EventArgs e)
    {
        (Parent as FlyoutPage).Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(EditProfilePage)));
    }
}