using ChatbotMauiClient.API;
using ChatbotMauiClient.API.Responses.Models;
using ChatbotMauiClient.Domain;
using ChatbotMauiClient.Domain.Models;
using ChatbotMauiClient.Services;

namespace ChatbotMauiClient.Pages.UserPages;

public partial class ConsultingPage : ContentPage
{
	public ConsultingPage()
	{
        BindingContext = AuthService.Instance.CurrentUserViewModel;
        NavigationPage.SetHasNavigationBar(this, false);
        InitializeComponent();
        //KnoTypesPicker.ItemsSource = MockHelper.Departmens;
    }

    private void MenuClicked(object sender, EventArgs e)
    {
        (Parent.Parent as FlyoutPage).IsPresented = true;
    }

    private async void KnoTypesPicker_SelectedIndexChanged(object sender, EventArgs e)
    {
        if((sender as Picker).SelectedIndex != -1)
        {
            var selected = (sender as Picker).SelectedItem as DepartmentModel;
            //ControlTypesPicker.ItemsSource = MockHelper.ControlTypes.Where(ct => ct.DepartmentId==selected.Id).ToList();
            ControlTypesPicker.ItemsSource = (await ControlApi.Instance.GetControls(selected.Id)).Response.ToList();
            ControlTypesPicker.IsVisible = true;
            ControlTypesPicker.SelectedIndex = -1;
            ConsultTypesPicker.SelectedIndex = -1;
            NextButton.IsEnabled = false;
        }
    }

    private async void ControlTypesPicker_SelectedIndexChanged(object sender, EventArgs e)
    {
        if ((sender as Picker).SelectedIndex != -1)
        {
            var selected = (sender as Picker).SelectedItem as ControlModel;
            //ConsultTypesPicker.ItemsSource = MockHelper.ConsultTypes.Where(ct => ct.ControlId == selected.Id).ToList();
            ConsultTypesPicker.ItemsSource = (await ControlApi.Instance.GetThemes(selected.Id)).Response.ToList();
            ConsultTypesPicker.IsVisible = true;
            ConsultTypesPicker.SelectedIndex = -1;
            NextButton.IsEnabled = false;
        }
    }

    private void ConsultTypesPicker_SelectedIndexChanged(object sender, EventArgs e)
    {
        NextButton.IsEnabled = (sender as Picker).SelectedIndex != -1;
    }

    private async void NextButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushAsync(new ConsultingCalendarPage());
    }

    private async void ContentPage_Appearing(object sender, EventArgs e)
    {
        KnoTypesPicker.ItemsSource = (await ControlApi.Instance.GetDepartments()).Response.ToList();
    }
}