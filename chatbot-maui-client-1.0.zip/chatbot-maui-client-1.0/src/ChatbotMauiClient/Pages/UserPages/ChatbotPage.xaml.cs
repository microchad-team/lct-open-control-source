using ChatbotMauiClient.Services;
using ChatbotMauiClient.API.Responses;

namespace ChatbotMauiClient.Pages.UserPages;

public partial class ChatbotPage : ContentPage
{
    public ChatbotPage()
    {
        NavigationPage.SetHasNavigationBar(this, false);
        InitializeComponent();
    }

    private async void ContentPage_Appearing(object sender, EventArgs e)
    {
        var messageResponse = await CHADBot.GetInitMessage();
        DrawMessageBot(messageResponse.Message);
        DrawButtons(messageResponse.Buttons);
    }

    private void MenuClicked(object sender, EventArgs e)
    {
        (Parent.Parent as FlyoutPage).IsPresented = true;
    }

    List<Label> textMessages = new List<Label>();
    List<Label> messages = new List<Label>();
    ChatBotService CHADBot = new ChatBotService();

    Label lbl1 = new Label { Text = "������ " + 1 };
    Label lbl2 = new Label { Text = "������ " + 2 };
    Label lbl3 = new Label { Text = "������ " + 3 };
    Label lbl4 = new Label { Text = "������ " + 4 };
    Label botAnswer;

    Frame btn1 = new Frame();
    Frame btn2 = new Frame();
    Frame btn3 = new Frame();
    Frame btn4 = new Frame();

    Frame btnsMessages = new Frame();

    private async void DrawButtons(List<ChatbotButton> buttons)
    {
        StackLayout stackLayout = new StackLayout()
        {
            Orientation = StackOrientation.Horizontal,
            Padding = 5
        };
        StackLayout stackLayoutBtns = new StackLayout()
        {
            Orientation = StackOrientation.Vertical
        };
        foreach (var button in buttons)
        {
            stackLayoutBtns.Children.Add(DrawSingleButton(button, stackLayout));
        }

        stackLayout.Children.Add(stackLayoutBtns);
        stackLayout.Children.Add(new Label
        {
            WidthRequest = 30,
            HorizontalOptions = LayoutOptions.EndAndExpand
        });
        stackLayout.Parent = null;
        stackChad.Parent = null;
        stackChad.Children.Add(stackLayout);
    }

    private Frame DrawSingleButton(ChatbotButton button, StackLayout stackLayout)
    {
        var label = new Label
        {
            Text = button.Text,
            Margin = 7,
            TextColor = Color.FromRgba(6, 6, 6, 100)
        };
        var tap = new TapGestureRecognizer();
        tap.Tapped += (s, e) =>
        {
            PerformAction(button.Action);
            stackLayout.IsVisible = false;
            DrawMessageUser(button.Text);
        };
        label.GestureRecognizers.Add(tap);
        var uiButton = new Frame
        {
            Margin = 5,
            Padding = 5,
            Background = Color.FromRgba(250, 154, 141, 100),
            HorizontalOptions = LayoutOptions.StartAndExpand,
            MaximumWidthRequest = 300
        };
        uiButton.Content = label;
        return uiButton;
    }

    private async void PerformAction(API.Responses.Action action)
    {
        var type = action.ActionType;
        switch (type)
        {
            //TODO: ���������� ��������� ����
            case 0:
                var messageResponse = await CHADBot.PerformGenericChatAction(action);
                DrawMessageBot(messageResponse.Message);
                DrawButtons(messageResponse.Buttons);
                break;
            case 1:
                Console.WriteLine($"���������� {action.ActionLink}");
                break;
            case 2:
                Console.WriteLine($"�������� ������ �� ����������������");
                break;
            case 3:
                Console.WriteLine($"�������� ���� � ��������");
                break;
        }
    }

    private async void DrawBtns(List<ChatbotButton> buttons)
    {
        StackLayout stackLayout = new StackLayout()
        {
            Orientation = StackOrientation.Horizontal,
            Padding = 5
        };
        StackLayout stackLayoutBtns = new StackLayout()
        {
            Orientation = StackOrientation.Vertical
        };

        if (buttons == null)
        {
            botAnswer = new Label { Text = "�� ������ ������� ������ �� �������. ���������� ���������� �� ����������������", TextColor = Color.FromRgba(6, 6, 6, 100) };
            stackLayoutBtns.Children.Add(botAnswer);
            stackLayout.Children.Add(new Label
            {
                WidthRequest = 30,
                HorizontalOptions = LayoutOptions.EndAndExpand
            });
            stackLayout.Parent = null;
            stackChad.Parent = null;
            stackChad.Children.Add(stackLayout);
            return;
        }

        botAnswer = new Label { Text = "��� ��� � ���� ���������� ��� �� ������� �������:", TextColor = Color.FromRgba(6, 6, 6, 100) };
        stackLayoutBtns.Children.Add(botAnswer);
        foreach (var btn in buttons.Take(5))
        {
            var lbl = new Label
            {
                Text = btn.Text,
                Margin = 7,
                TextColor = Color.FromRgba(6, 6, 6, 100)
            };

            var btnView = new Frame
            {
                Margin = 5,
                Padding = 5,
                Background = Color.FromRgba(250, 154, 141, 100),
                HorizontalOptions = LayoutOptions.StartAndExpand,
                MaximumWidthRequest = 300,
                Content = lbl
            };

            var tap = new TapGestureRecognizer();
            tap.Tapped += (s, e) =>
            {
                stackLayoutBtns.IsVisible = false;
                DrawMessageUser(lbl.Text);
            };

            lbl.GestureRecognizers.Add(tap);
            stackLayoutBtns.Children.Add(btnView);
        }

        stackLayout.Children.Add(stackLayoutBtns);
        stackLayout.Children.Add(new Label
        {
            WidthRequest = 30,
            HorizontalOptions = LayoutOptions.EndAndExpand
        });
        stackLayout.Parent = null;
        stackChad.Parent = null;
        stackChad.Children.Add(stackLayout);
    }

    private void btn0_click()
    {
        btn1.IsVisible = false;
        btn2.IsVisible = false;
        btn3.IsVisible = false;
        btn4.IsVisible = false;
        botAnswer.IsVisible = false;
        DrawMessageUser(lbl1.Text);
    }
    private void btn1_click()
    {
        btn1.IsVisible = false;
        btn2.IsVisible = false;
        btn3.IsVisible = false;
        btn4.IsVisible = false;
        botAnswer.IsVisible = false;
        DrawMessageUser(lbl2.Text);
    }
    private void btn2_click()
    {
        btn1.IsVisible = false;
        btn2.IsVisible = false;
        btn3.IsVisible = false;
        btn4.IsVisible = false;
        botAnswer.IsVisible = false;
        DrawMessageUser(lbl3.Text);
    }
    private void btn3_click()
    {
        btn1.IsVisible = false;
        btn2.IsVisible = false;
        btn3.IsVisible = false;
        btn4.IsVisible = false;
        botAnswer.IsVisible = false;
        DrawMessageUser(lbl4.Text);
    }

    private async void DrawMessageUser(string textMessage)
    {
        StackLayout stackMessage = new StackLayout
        {
            Margin = 5
        };
        messages.Add(new Label
        {
            Text = textMessage,
            TextColor = Color.FromRgba(6, 6, 6, 100)
        });
        Frame message = new Frame
        {
            Margin = 0,
            Padding = 5,
            Background = Color.FromRgba(250, 154, 141, 100),
            HorizontalOptions = LayoutOptions.EndAndExpand,
            MaximumWidthRequest = 300
        };
        message.Content = messages[messages.Count - 1];
        stackMessage.Children.Add(message);
        stackChad.Children.Add(stackMessage);

        entryField.Text = "";

    }


    private async void DrawMessageBot(string textMessage)
    {
        messages.Add(new Label
        {
            Text = textMessage,
            Margin = 7,
            TextColor = Color.FromRgba(6, 6, 6, 100)

        });
        Frame message = new Frame
        {
            Margin = 5,
            Padding = 5,
            Background = Color.FromRgba(230, 230, 230, 100),
            HorizontalOptions = LayoutOptions.StartAndExpand,
            MaximumWidthRequest = 300
        };
        message.Content = messages[messages.Count - 1];
        stackChad.Children.Add(message);

    }


    bool voice = true;
    private async void Button_Clicked(object sender, EventArgs e)
    {
        if (btn1 != null)
            btn1.IsVisible = false;
        if (btn2 != null)
            btn2.IsVisible = false;
        if (btn3 != null)
            btn3.IsVisible = false;
        if (btn4 != null)
            btn4.IsVisible = false;
        if (botAnswer != null)
            botAnswer.IsVisible = false;

        var message = entryField.Text;
        if (!string.IsNullOrWhiteSpace(message))
        {
            if (voice)
            {
                //var result = await CrossSpeechToText.StartVoiceInput("Voice Input!");
                //DrawMessageUser(result);
                //DrawMessageBot(CHADBot.getMessage());
                //DrawBtns();
            }
            else
            {
                var chatbotButtons = await CHADBot.GetMessage(entryField.Text);
                DrawMessageUser(entryField.Text);
                //DrawMessageBot(await CHADBot.GetMessage(entryField.Text));
                DrawBtns(chatbotButtons);
            }
        }
    }

    private void entryField_TextChanged(object sender, TextChangedEventArgs e)
    {
        voice = string.IsNullOrWhiteSpace(entryField.Text);
    }


}