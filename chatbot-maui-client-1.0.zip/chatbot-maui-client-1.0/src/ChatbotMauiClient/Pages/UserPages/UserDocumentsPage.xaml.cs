using ChatbotMauiClient.Domain;
using ChatbotMauiClient.Domain.Models;
using ChatbotMauiClient.Pages.SlotPages;
using ChatbotMauiClient.Services;
using ChatbotMauiClient.ViewModels;

namespace ChatbotMauiClient.Pages.UserPages;

public partial class UserDocumentsPage : ContentPage
{
    private bool isApprovedButtonClicked = true;
    private bool isWaitingButtonClicked = true;
    private UserViewModel currentUser = AuthService.Instance.CurrentUserViewModel;

    public UserDocumentsPage()
	{
        NavigationPage.SetHasNavigationBar(this, false);
        InitializeComponent();
        BindingContext = MockHelper.Slots.Select(slot => new SlotViewModel(slot)).Where(s => s.UserId == currentUser.Id);
    }

    private void MenuClicked(object sender, EventArgs e)
    {
        (Parent.Parent as FlyoutPage).IsPresented = true;
    }

    private void ApprovedButtonFilter_Tapped(object sender, TappedEventArgs e)
    {
        isApprovedButtonClicked = !isApprovedButtonClicked;
        (sender as Frame).BorderColor = Color.FromArgb(isApprovedButtonClicked ? "#FA9A8D" : "#C4C4C4");
        BindingContext = MockHelper.Slots
            .Select(slot => new SlotViewModel(slot))
            .Where(s => s.UserId == currentUser.Id && (s.IsApproved && isApprovedButtonClicked || s.IsNotApproved && isWaitingButtonClicked));
    }
    private void WaitingButtonFilter_Tapped(object sender, TappedEventArgs e)
    {
        isWaitingButtonClicked = !isWaitingButtonClicked;
        (sender as Frame).BorderColor = Color.FromArgb(isWaitingButtonClicked ? "#FA9A8D" : "#C4C4C4");
        BindingContext = MockHelper.Slots
            .Select(slot => new SlotViewModel(slot))
            .Where(s => s.UserId == currentUser.Id && (s.IsApproved && isApprovedButtonClicked || s.IsNotApproved && isWaitingButtonClicked));
    }

    private async void listviewApprovedDocuments_ItemSelected(object sender, SelectedItemChangedEventArgs e)
    {
        var item = (sender as ListView).SelectedItem as SlotViewModel;
        if (item != null)
        {
            (sender as ListView).SelectedItem = null;
            await Navigation.PushAsync(new SlotPage(item, false));
        }
    }
}