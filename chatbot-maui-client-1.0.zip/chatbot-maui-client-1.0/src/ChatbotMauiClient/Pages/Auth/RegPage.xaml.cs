using ChatbotMauiClient.Services;

namespace ChatbotMauiClient.Pages.Auth;

public partial class RegPage : ContentPage
{
	public RegPage()
	{
        NavigationPage.SetHasBackButton(this, false);
        NavigationPage.SetHasNavigationBar(this, false);
        InitializeComponent();
	}

    private async void RegActionHandler(object sender, EventArgs e)
    {
        var login = LoginEntry.Text;
        var pass = PassEntry.Text;

        try
        {
            var registerResult = await AuthService.Instance.Register(login, pass);
            if (registerResult)
            {
                Unfocus();
                AuthPage.Instance.Login(login, pass, true);
                return;
            }
            await DisplayAlert("������", "����� � �������� ����������...", "�K");
        }
        catch (Exception)
        {
            await DisplayAlert("������", "����� � �������� ����������...", "�K");
        }
    }

    private void Page_Appearing(object sender, EventArgs e)
    {
        LoginEntry.Text = "";
        PassEntry.Text = "";
    }

    public void Unfocus()
    {
        LoginEntry.IsEnabled = false;
        LoginEntry.IsEnabled = true;
        PassEntry.IsEnabled = false;
        PassEntry.IsEnabled = true;
        LoginEntry.Unfocus();
        PassEntry.Unfocus();
    }
}