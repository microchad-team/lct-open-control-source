using ChatbotMauiClient.Domain.Models;
using ChatbotMauiClient.Pages.Lk;
using ChatbotMauiClient.Services;
using ChatbotMauiClient.ViewModels;

namespace ChatbotMauiClient.Pages.Auth;

public partial class AuthPage : ContentPage
{
    public static AuthPage Instance;

    public AuthPage()
    {
        NavigationPage.SetHasBackButton(this, false);
        NavigationPage.SetHasNavigationBar(this, false);
        InitializeComponent();
        Instance = this;
    }

    private async void LoginActionHandler(object sender, EventArgs e)
    {
        var login = LoginEntry.Text;
        var pass = PassEntry.Text;
        var mustSaveUser = SaveUserCheckBox.IsChecked;

        try
        {
            Login(login, pass, mustSaveUser);
        }
        catch (Exception)
        {
            await DisplayAlert("������", "����� � �������� ����������...", "�K");
        }
    }

    private void GoToRegisterPage(object sender, EventArgs e)
    {
        (this.Parent as TabbedPage).CurrentPage = (Parent as TabbedPage).Children[1];
    }

    private void Page_Appearing(object sender, EventArgs e)
    {
        LoginEntry.Text = "";
        PassEntry.Text = "";
    }

    public async void Login(string login, string pass, bool mustSaveUser)
    {
        UserViewModel user = await AuthService.Instance.Login(login, pass);
        if (user != null)
        {
            if(mustSaveUser)
            {
                await AuthService.Instance.SaveUserCredentials(new UserCredentials()
                {
                    Id = user.Id,
                    Login = login,
                    Password = pass,
                    Username = user.Username,
                    IsKno = user.IsKno
                });
            }
            UnfocusEnries();
            Page lkPage = user.IsKno ? new KnoLkPage() : new UserLkPage();
            //await DisplayAlert("�����", "�� �����", "�K");
            await Navigation.PushAsync(lkPage);
        }
    }

    public void UnfocusEnries()
    {
        LoginEntry.IsEnabled = false;
        LoginEntry.IsEnabled = true;
        PassEntry.IsEnabled = false;
        PassEntry.IsEnabled = true;
        LoginEntry.Unfocus();
        PassEntry.Unfocus();
    }
}