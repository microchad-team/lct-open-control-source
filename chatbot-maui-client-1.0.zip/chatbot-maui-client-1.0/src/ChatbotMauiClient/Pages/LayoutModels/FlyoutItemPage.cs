﻿namespace ChatbotMauiClient.Pages.LayoutModels;

public class FlyoutItemPage
{
    public string Title { get; set; }
    public string IconSource { get; set; }
    public Type TargetPage { get; set; }
    public string Color { get; set; }
    public bool WithNotifications { get; set; }
    public int NotificationCounter { get; set; }
    public string NotificationCounterText 
    { 
        get 
        {
            if (NotificationCounter > 9) return "9+";
            return NotificationCounter.ToString();
        }
    }
    public bool IsNotificationsExist
    {
        get => WithNotifications && NotificationCounter != 0;
    }
}
