﻿using System.Globalization;

namespace ChatbotMauiClient.Pages.LayoutModels;

public class StringToColorConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var color = value.ToString();
        if (color.Contains("#"))
        {
            return Color.FromArgb(color);
        }
        switch (color)
        {
            case "DarkGray":
                return Colors.DarkGray;
            default:
                return Colors.LightGray;
        }
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        return null;
    }
}
