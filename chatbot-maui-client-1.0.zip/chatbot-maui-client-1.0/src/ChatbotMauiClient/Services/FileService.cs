﻿using ChatbotMauiClient.API.Requests;
using CommunityToolkit.Maui.Storage;
using Newtonsoft.Json;

namespace ChatbotMauiClient.Services
{
    public class FileService
    {
        private IFileSaver fileSaver;

        private string appPath = FileSystem.Current.AppDataDirectory;

        private static FileService instance;
        public static FileService Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new FileService();
                }
                return instance;
            }
        }

        private FileService()
        {
            this.fileSaver = FileSaver.Default;
        }

        public async Task SaveFile(string path, object data)
        {
            var content = JsonConvert.SerializeObject(data);
            var fullpath = Path.Combine(appPath, path);
            File.WriteAllText(fullpath, content);
        }

        public T GetFileContent<T>(string path) where T : class
        {
            var fullpath = Path.Combine(appPath, path);
            if (File.Exists(fullpath))
            {
                string content = File.ReadAllText(fullpath);
                return JsonConvert.DeserializeObject<T>(content);
            }
            return null;
        }

        public async Task<T> GetFileContentAsync<T>(string path) where T : class
        {
            var fullpath = Path.Combine(appPath, path);
            if (File.Exists(fullpath))
            {
                string content = await File.ReadAllTextAsync(fullpath);
                return JsonConvert.DeserializeObject<T>(content);
            }
            return null;
        }

        public async Task DeleteFile(string path)
        {
            var fullpath = Path.Combine(appPath, path);
            if (File.Exists(fullpath))
            {
                File.Delete(fullpath);
            }
        }


        //public async Task SaveUserCredentials(LoginRequest loginRequest)
        //{
        //    var content = JsonConvert.SerializeObject(loginRequest);
        //    File.WriteAllText(credentialsPath, content);
        //    //using var stream = new MemoryStream(Encoding.Default.GetBytes(content));
        //    //var path = await fileSaver.SaveAsync(credentialsPath, stream, cancellationTokenSource.Token);
        //}

        //public async Task<LoginRequest> GetUserCredentials()
        //{
        //    if(File.Exists(credentialsPath))
        //    {
        //        string content = await File.ReadAllTextAsync(credentialsPath);
        //        return JsonConvert.DeserializeObject<LoginRequest>(content);
        //    }
        //    return null;
        //    //using Stream fileStream = await FileSystem.Current.OpenAppPackageFileAsync(credentialsPath);
        //    //using StreamReader reader = new StreamReader(fileStream);
        //    //string content = await reader.ReadToEndAsync();
        //    //return JsonConvert.DeserializeObject<LoginRequest>(content);
        //}

        //public async Task DeleteUserCredentials()
        //{
        //    if (File.Exists(credentialsPath))
        //    {
        //        File.Delete(credentialsPath);
        //    }
        //    //using Stream fileStream = await FileSystem.Current.OpenAppPackageFileAsync(credentialsPath);
        //    //using StreamReader reader = new StreamReader(fileStream);
        //    //string content = await reader.ReadToEndAsync();
        //    //return JsonConvert.DeserializeObject<LoginRequest>(content);
        //}
    }
}
