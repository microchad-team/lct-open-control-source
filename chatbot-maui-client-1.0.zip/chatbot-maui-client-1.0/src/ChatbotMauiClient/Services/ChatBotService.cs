﻿using ChatbotMauiClient.API;
using ChatbotMauiClient.API.Requests;
using ChatbotMauiClient.API.Responses;

namespace ChatbotMauiClient.Services;

public class ChatBotService
{
    ChatbotApi api = ChatbotApi.Instance;
    public async Task<List<ChatbotButton>> GetMessage(string message)
    {
        var clearMessage = System.Text.RegularExpressions.Regex.Replace(message.Trim(), @"\s+", " ");
        try
        {
            var messageRequest = new MessageRequest()
            {
                 UserId = AuthService.Instance.CurrentUserViewModel.Id.ToString(),
                 Message = clearMessage
            };

            var serverResponse = await api.PostMessage(messageRequest);
            if (serverResponse.IsSuccess)
            {
                return serverResponse.Response.Buttons;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
        }
        return null;

        //return "По поводу задачи определения размера структурного элемента. В общем, эта задача вылезла сейчас" +
        //    " с очень высоким приоритетом.\r\nПосмотрел ваши соображения, понял не до конца.\r\nКак вариант, вот в " +
        //    "этой статье в т.ч. и про это есть.\r\nСамое простое (по ощущениям, не претендую на правоту) - находить ширину " +
        //    "L-направляющей. Она в 1 элемент толщиной.\r\nНо, вероятно, потребуются дополнительные проверки. К примеру, " +
        //    "по дорожкам синхронизации.\r\n\r\nПредлагаю подумать немного, завтра обсудить, какие варианты.\r\nВ универе " +
        //    "встретиться или в скайпе/зуме обсудить, я чуть позже напишу, к вечеру, наверное";
    }

    public async Task<MessageResponse> GetInitMessage()
    {
        var response = new MessageResponse()
        {
            Message = "Возникла ошибка при подключении к серверу"
        };
        try
        {
            var serverResponse = await api.GetInitMessage();
            if (serverResponse.IsSuccess)
            {
                response = serverResponse.Response;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
        }
        return response;
    }

    public async Task<MessageResponse> PerformGenericChatAction(API.Responses.Action action)
    {
        Console.WriteLine(action.ActionLink);
        var response = new MessageResponse()
        {
            Message = "Возникла ошибка при подключении к серверу"
        };
        try
        {
            var serverResponse = await api.GetNewMessage(action.ActionLink); 
            if (serverResponse.IsSuccess)
            {
                response = serverResponse.Response;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
        }

        return response;
    }
}
