﻿using ChatbotMauiClient.API;
using ChatbotMauiClient.API.Responses;
using ChatbotMauiClient.Domain.Models;
using ChatbotMauiClient.Pages;
using ChatbotMauiClient.ViewModels;

namespace ChatbotMauiClient.Services;

public class AuthService
{
    private string credentialsPath = "credentials.json";

    private static AuthService instance;
    public static AuthService Instance
    {
        get
        {
            if (instance == null)
            {
                instance = new AuthService();
            }
            return instance;
        }
    }
    private AuthService() { }

    public UserViewModel CurrentUserViewModel { get; set; }

    public async Task<UserViewModel> Login(string login, string password)
    {
        CommonResponse<LoginResponse> loginCommonResponse = await AuthApi.Instance.Login(login, password);
        if(loginCommonResponse.IsSuccess)
        {
            var loginResponse = loginCommonResponse.Response;
            CurrentUserViewModel = new UserViewModel(new User()
            {
                Id = loginResponse.Id,
                Username = loginResponse.Username,
                UserStatus = loginResponse.UserStatus,
                UserDepartment = loginResponse.UserDepartment,
                Role = loginResponse.Role,
                IsKno = loginResponse.Role == "admin"
            });
        }
        else
        {
            CurrentUserViewModel = null;
        }
        return CurrentUserViewModel;
    }

    public async Task<bool> Register(string login, string password)
    {
        var regResponse = await AuthApi.Instance.Register(login, password);
        return regResponse.IsSuccess;
    }

    public async void LogOut()
    {
        CurrentUserViewModel = null;
        await DeleteUserCredentials();
        var navigation = App.Current.MainPage.Navigation;
        if (navigation.NavigationStack.Count == 1)
        {
            navigation.InsertPageBefore(new MainPage(), navigation.NavigationStack[0]);
        }
        await navigation.PopAsync();
    }


    public async Task SaveUserCredentials(UserCredentials userCredentials)
    {
        await FileService.Instance.SaveFile(credentialsPath, userCredentials);
    }

    public UserCredentials GetUserCredentials()
    {
        return FileService.Instance.GetFileContent<UserCredentials>(credentialsPath);
    }

    public async Task<UserCredentials> GetUserCredentialsAsync()
    {
        return await FileService.Instance.GetFileContentAsync<UserCredentials>(credentialsPath);
    }

    public async Task DeleteUserCredentials()
    {
        await FileService.Instance.DeleteFile(credentialsPath);
    }
}
