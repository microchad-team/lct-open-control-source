﻿using Android;
using Android.App;
using Android.Content.PM;
using Android.OS;
using System.Diagnostics;
using Environment = System.Environment;

namespace ChatbotMauiClient;

[Activity(Theme = "@style/Maui.SplashTheme", MainLauncher = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation | ConfigChanges.UiMode | ConfigChanges.ScreenLayout | ConfigChanges.SmallestScreenSize | ConfigChanges.Density)]
public class MainActivity : MauiAppCompatActivity
{
    protected override void OnCreate(Bundle savedInstanceState)
    {
        base.OnCreate(savedInstanceState);
        AppDomain.CurrentDomain.UnhandledException += CurrentDomainOnUnhandledException;
        TaskScheduler.UnobservedTaskException += TaskSchedulerOnUnobservedTaskException;

        if (CheckSelfPermission(Manifest.Permission.WriteExternalStorage) != Android.Content.PM.Permission.Granted)
            RequestPermissions(new string[] { Manifest.Permission.WriteExternalStorage }, 0);

        DisplayCrashReport();
    }


    #region Error handling
    private static void TaskSchedulerOnUnobservedTaskException(object sender, UnobservedTaskExceptionEventArgs unobservedTaskExceptionEventArgs)
    {
        var newExc = new Exception("TaskSchedulerOnUnobservedTaskException", unobservedTaskExceptionEventArgs.Exception);
        LogUnhandledException(newExc);
    }

    private static void CurrentDomainOnUnhandledException(object sender, UnhandledExceptionEventArgs unhandledExceptionEventArgs)
    {
        var newExc = new Exception("CurrentDomainOnUnhandledException", unhandledExceptionEventArgs.ExceptionObject as Exception);
        LogUnhandledException(newExc);
    }

    internal static void LogUnhandledException(Exception exception)
    {
        try
        {
            const string errorFileName = "Fatal.log";
            var libraryPath = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            var errorFilePath = Path.Combine(libraryPath, errorFileName);
            var exceptionReport = exception.InnerException?.Message + Environment.NewLine + Environment.NewLine +
                "Stack trace:" + exception.InnerException?.StackTrace + Environment.NewLine + Environment.NewLine +
                "Outer exception: " + exception.ToString();
            var errorMessage = string.Format("Time: {0}\r\nError: Unhandled Exception\r\n{1}", DateTime.Now, exceptionReport);
            File.WriteAllText(errorFilePath, errorMessage);
        }
        catch
        {
            // just suppress any error logging exceptions
        }
    }

    //[Conditional("DEBUG")]
    private void DisplayCrashReport()
    {
        const string errorFilename = "Fatal.log";
        var libraryPath = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
        var errorFilePath = Path.Combine(libraryPath, errorFilename);

        if (!File.Exists(errorFilePath))
        {
            return;
        }

        var errorText = File.ReadAllText(errorFilePath);
        if (string.IsNullOrWhiteSpace(errorText))
        {
            return;
        }

        new AlertDialog.Builder(this)
            .SetNegativeButton("Close", (sender, args) =>
            {
                File.Delete(errorFilePath);
            })
            .SetMessage(errorText)
            .SetTitle("Crash Report")
            .Show();
    }
    #endregion
}
