package team.microchad.calendar.api.feign;

import org.springframework.cloud.openfeign.FeignClient;
import team.microchad.calendar.api.BusinessControllerApi;
import team.microchad.calendar.api.CalendarApi;
import team.microchad.calendar.api.DepartmentControllerApi;
import team.microchad.calendar.api.SlotControllerApi;

@FeignClient("ms-calendar")
public interface CalendarApiClient extends DepartmentControllerApi,
        BusinessControllerApi,
        SlotControllerApi,
        CalendarApi {
}
