package team.microchad.calendar.mapper;

import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import team.microchad.calendar.dto.ThemeDto;
import team.microchad.calendar.entity.Theme;

@Mapper(componentModel = "spring", injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public abstract class ThemeMapper {
    @Mapping(target = "controlType", source = "controlType.id")
    public abstract ThemeDto mapThemeToDto(Theme theme);
}
