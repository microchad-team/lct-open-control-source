package team.microchad.calendar.entity;

import jakarta.persistence.*;
import lombok.*;

import java.sql.Date;
import java.sql.Time;

@Getter
@Setter
@Builder
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "slot")
@IdClass(SlotId.class)
public class Slot {
    @Id
    private Date date;
    @Id
    private Time slotBegin;
    @Id
    @ManyToOne(optional = false)
    @JoinColumn(name = "department_id", nullable = false)
    private Department department;
    @Column
    private Time slotEnd;

    @Column(name = "business_id")
    private Long businessId;
    @Column(name = "control_id")
    private Long controlId;

    private Boolean isApproved;


}
