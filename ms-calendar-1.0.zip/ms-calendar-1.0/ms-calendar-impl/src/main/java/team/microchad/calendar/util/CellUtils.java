package team.microchad.calendar.util;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;

public class CellUtils {
    public static boolean isCellNotContainsNullOrEmptyString(Cell cell) {
        return cell != null
                && cell.getCellType() != CellType.BLANK
                && !cell.getStringCellValue().isEmpty();
    }

    public static boolean isCellNotContainsNullOrEmptyNumeric(Cell cell) {
        return cell != null
                && cell.getCellType() != CellType.NUMERIC
                && Double.isNaN(cell.getNumericCellValue());
    }

    public static boolean isCellNotContainsNullOrEmptyDate(Cell cell) {
        return cell != null
                && cell.getCellType() != CellType.BLANK;
    }
}
