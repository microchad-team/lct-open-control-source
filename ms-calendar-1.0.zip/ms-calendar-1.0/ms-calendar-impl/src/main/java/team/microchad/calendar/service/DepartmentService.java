package team.microchad.calendar.service;

import lombok.RequiredArgsConstructor;
import org.hibernate.metamodel.relational.IllegalIdentifierException;
import org.springframework.stereotype.Service;
import team.microchad.calendar.dto.DepartmentDto;
import team.microchad.calendar.mapper.DepartmentMapper;
import team.microchad.calendar.repository.DepartmentRepository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.StreamSupport;

@Service
@RequiredArgsConstructor
public class DepartmentService {
    public static final String DEPARTMENT_ID_DIDN_T_PROVIDED = "Department id didn't provided";
    private final DepartmentRepository departmentRepository;
    private final DepartmentMapper mapper;

    public List<DepartmentDto> findAll() {
        return mapper.departmentToDepartmentDto(StreamSupport
                .stream(departmentRepository.findAll().spliterator(),
                        false).toList());
    }

    public DepartmentDto findById(Long id) throws NoSuchElementException {
        return mapper.departmentToDepartmentDto(departmentRepository.findById(id).orElseThrow());
    }

    public void save(DepartmentDto entity) {
        departmentRepository.save(mapper.departmentDtoToDepartment(entity));
    }

    public void delete(Long id) {
        departmentRepository.deleteById(id);
    }

    public void update(DepartmentDto dto) throws NoSuchElementException, IllegalIdentifierException {
        if (dto.getId() != null) {
            departmentRepository.findById(dto.getId()).orElseThrow();
            departmentRepository.save(mapper.departmentDtoToDepartment(dto));
        } else {
            throw new IllegalIdentifierException(DEPARTMENT_ID_DIDN_T_PROVIDED);
        }
    }
}
