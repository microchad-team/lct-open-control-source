package team.microchad.calendar.service;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.hibernate.metamodel.relational.IllegalIdentifierException;
import org.springframework.stereotype.Service;
import team.microchad.calendar.dto.BusinessDto;
import team.microchad.calendar.dto.DepartmentDto;
import team.microchad.calendar.dto.SlotDto;
import team.microchad.calendar.entity.Department;
import team.microchad.calendar.entity.Slot;

import team.microchad.calendar.entity.SlotId;
import team.microchad.calendar.mapper.PersonalDataMapper;
import team.microchad.calendar.mapper.SlotMapper;
import team.microchad.calendar.repository.DepartmentRepository;
import team.microchad.calendar.repository.SlotRepository;
import team.microchad.calendar.service.client.LkClient;
import team.microchad.lk.dto.PersonalData;

import java.sql.Date;
import java.sql.Time;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.StreamSupport;

@Service
@RequiredArgsConstructor
public class SlotService {
    public static final String SLOT_ID_DIDN_T_PROVIDED = "Slot id didn't provided";
    private final SlotRepository slotRepository;
    private final SlotMapper mapper;
    private final PersonalDataMapper personalDataMapper;
    private final LkClient lkClient;
    private final DepartmentRepository departmentRepository;

    public List<SlotDto> findAll() {
        return mapper.slotToSlotDto(StreamSupport
                .stream(slotRepository
                        .findAll()
                        .spliterator(), false)
                .toList());
    }

    public SlotDto findById(Date date, Time time, Long department) throws NoSuchElementException {
        SlotId id = new SlotId(date, time, department);
        var slot = slotRepository.findById(id).orElseThrow();
        var slotDto = mapper.slotToSlotDto(slot);
        if (slot.getBusinessId() != null) {
            slotDto.setBusiness(getUserInfo(slot.getBusinessId()));
        }
        if (slot.getControlId() != null) {
            var departmentInfo = getDepartmentInfo(slot.getControlId());
            slotDto.setDepartment(departmentInfo);
            var departmentRecord = departmentRepository
                    .findById(department)
                    .orElseThrow();
            slotDto.getDepartment().setDepartmentName(departmentRecord.getTitle());
            slotDto.getDepartment().setId(departmentRecord.getId());
            slotDto.getDepartment().setControlId(slot.getControlId());
        }
        return slotDto;
    }

    public void save(SlotDto dto) {
        Slot slot = mapper.slotDtoToSlot(dto);
        slotRepository.save(slot);
    }

    public void saveAll(List<Slot> slots) {
        slotRepository.saveAll(slots);
    }

    public void delete(Date date, Time time, Long department) {
        SlotId id = new SlotId(Date.valueOf(date.toLocalDate()), Time.valueOf(time.toLocalTime()), department);
        slotRepository.deleteById(id);
    }

    @Transactional
    public void update(SlotDto slot) throws NoSuchElementException, IllegalIdentifierException {
        var entity = mapper.slotDtoToSlot(slot);
        if (entity.getDate() != null && entity.getSlotBegin() != null && entity.getDepartment().getId() != null) {
            SlotId id = new SlotId(entity.getDate(), entity.getSlotBegin(), entity.getDepartment().getId());
            slotRepository.findById(id).orElseThrow();
            slotRepository.save(entity);
        } else {
            throw new IllegalIdentifierException(SLOT_ID_DIDN_T_PROVIDED);
        }
    }

    private BusinessDto getUserInfo(Long userId) {
        PersonalData data = lkClient.getUser(userId).getBody();
        return personalDataMapper.personalDataToBusinessDto(data);
    }

    private DepartmentDto getDepartmentInfo(Long userId) {
        PersonalData data = lkClient.getUser(userId).getBody();
        return personalDataMapper.personalDataToDepartmentDto(data);
    }
}
