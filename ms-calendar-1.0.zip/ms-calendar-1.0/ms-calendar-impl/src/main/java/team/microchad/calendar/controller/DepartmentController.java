package team.microchad.calendar.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import team.microchad.calendar.api.DepartmentControllerApi;
import team.microchad.calendar.dto.DepartmentDto;
import team.microchad.calendar.service.DepartmentService;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class DepartmentController implements DepartmentControllerApi {
    private static final String DEPARTMENT_STORED = "Department stored";
    private static final String DEPARTMENT_DELETED = "Department deleted";
    private static final String DEPARTMENT_UPDATED = "Department updated";
    private final DepartmentService departmentService;

    @Override
    public ResponseEntity<List<DepartmentDto>> getAllDepartments() {
        return ResponseEntity.ok(departmentService.findAll());
    }

    @Override
    public ResponseEntity<DepartmentDto> getDepartmentById(Long id) {
        return ResponseEntity.ok(departmentService.findById(id));
    }

    @Override
    public ResponseEntity<String> postDepartment(DepartmentDto department) {
        departmentService.save(department);
        return ResponseEntity.ok(DEPARTMENT_STORED);
    }

    @Override
    public ResponseEntity<String> deleteDepartment(Long id) {
        departmentService.delete(id);
        return ResponseEntity.ok(DEPARTMENT_DELETED);
    }

    @Override
    public ResponseEntity<String> putDepartment(DepartmentDto department) {
        departmentService.update(department);
        return ResponseEntity.ok(DEPARTMENT_UPDATED);
    }

}
