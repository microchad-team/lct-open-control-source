package team.microchad.calendar.controller;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import team.microchad.calendar.api.ControlTypeApi;
import team.microchad.calendar.dto.ControlTypeDto;
import team.microchad.calendar.entity.Department;
import team.microchad.calendar.mapper.ControlTypeMapper;
import team.microchad.calendar.repository.ControlTypeRepository;
import team.microchad.calendar.repository.DepartmentRepository;
import team.microchad.calendar.repository.ThemeRepository;
import team.microchad.calendar.service.ParsingService;

import java.io.IOException;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class ControlTypeControllerImpl implements ControlTypeApi {
    private final ParsingService parsingService;
    private final ControlTypeRepository controlTypeRepository;
    private final DepartmentRepository departmentRepository;
    private final ThemeRepository themeRepository;
    private final ControlTypeMapper controlTypeMapper;

    @Override
    public ResponseEntity<List<ControlTypeDto>> getByDepartment(Long departmentId) {
        Department department = departmentRepository.findById(departmentId).orElseThrow();
        return ResponseEntity.ok(controlTypeRepository.findAllByDepartment(department).stream()
                .map(controlTypeMapper::mapControlTypeToDto).toList());
    }

    @Override
    @SneakyThrows(IOException.class)
    public ResponseEntity<Void> postXlsx(Resource body) {
        themeRepository.saveAll(parsingService.parseConsultingThemeXlsx(body.getInputStream()));
        return ResponseEntity.ok().build();
    }
}
