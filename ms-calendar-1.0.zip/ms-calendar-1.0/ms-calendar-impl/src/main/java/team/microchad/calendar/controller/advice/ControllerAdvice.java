package team.microchad.calendar.controller.advice;

import org.hibernate.metamodel.relational.IllegalIdentifierException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.io.IOException;
import java.util.NoSuchElementException;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

@RestControllerAdvice
public class ControllerAdvice {

    private static final String NO_SUCH_ELEMENT = "No such element";
    private static final String ID_UNPROVIDED = "Id unprovided";
    private static final String EXCEPTION_DURING_PARSING_SLOTS = "Exception during parsing slots";

//    @ExceptionHandler(NoSuchElementException.class)
//    @ResponseStatus(BAD_REQUEST)
//    public ResponseEntity<String> handleNoSuchElementException() {
//        return ResponseEntity.badRequest().body(NO_SUCH_ELEMENT);
//    }

    @ExceptionHandler(IllegalIdentifierException.class)
    @ResponseStatus(BAD_REQUEST)
    public ResponseEntity<String> handleIllegalIdentifierException() {
        return ResponseEntity.badRequest().body(ID_UNPROVIDED);
    }

    /*@ExceptionHandler(IOException.class)
    @ResponseStatus(BAD_REQUEST)
    public ResponseEntity<String> handleIOException() {
        return ResponseEntity.badRequest().body(EXCEPTION_DURING_PARSING_SLOTS);
    }*/
}
