package team.microchad.calendar.mapper;

import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import team.microchad.calendar.dto.BusinessDto;
import team.microchad.calendar.dto.DepartmentDto;
import team.microchad.lk.dto.PersonalData;
import team.microchad.lk.dto.UserDto;

@Mapper(componentModel = "spring", injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public abstract class PersonalDataMapper {

    @Mapping(target = "userName", expression = "java(pd.getName() + \" \" + pd.getPatronymic() + \" \" + pd.getLastName())")
    @Mapping(target = "id", source = "userId")
    public abstract BusinessDto personalDataToBusinessDto(PersonalData pd);

    @Mapping(target = "userName", expression = "java(pd.getName() + \" \" + pd.getPatronymic() + \" \" + pd.getLastName())")
    @Mapping(target = "id", source = "userId")
    public abstract DepartmentDto personalDataToDepartmentDto(PersonalData pd);
}
