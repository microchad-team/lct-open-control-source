package team.microchad.calendar.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import team.microchad.calendar.api.CalendarApi;
import team.microchad.calendar.dto.CalendarDto;
import team.microchad.calendar.service.CalendarService;

import java.time.LocalDate;

@RestController
@RequiredArgsConstructor
public class CalendarControllerImpl implements CalendarApi {
    private final CalendarService calendarService;

    @Override
    public ResponseEntity<CalendarDto> getCalendar(Boolean free, Long department, LocalDate since, LocalDate until) {
        return ResponseEntity.ok(calendarService.findByCriteria(free, department, since, until));
    }
}
