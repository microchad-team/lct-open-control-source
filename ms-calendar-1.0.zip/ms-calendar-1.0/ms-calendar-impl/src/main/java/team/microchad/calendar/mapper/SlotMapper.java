package team.microchad.calendar.mapper;

import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import team.microchad.calendar.dto.SlotDto;
import team.microchad.calendar.entity.Slot;

import java.sql.Time;
import java.util.List;

@Mapper(componentModel = "spring", injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public abstract class SlotMapper {

    @Mapping(target = "slotBegin", expression = "java(slot.getSlotBegin().toString())")
    @Mapping(target = "slotEnd", expression = "java(slot.getSlotEnd().toString())")
    public abstract SlotDto slotToSlotDto(Slot slot);

    @Mapping(target = "controlId", source = "department.controlId")
    @Mapping(target = "businessId", expression = "java(slot.getBusiness().getId())")
    @Mapping(target = "slotBegin", source = "slotBegin")
    @Mapping(target = "slotEnd", source = "slotEnd")
    @Mapping(target = "department", expression = "java(Department.builder().id(slot.getDepartment().getId()).build())")
    public abstract Slot slotDtoToSlot(SlotDto slot);

    public abstract List<SlotDto> slotToSlotDto(List<Slot> slots);

    public abstract List<Slot> slotDtoToSlot(List<SlotDto> slots);

    public Time map(String value) {
        return Time.valueOf(value);
    }
}
