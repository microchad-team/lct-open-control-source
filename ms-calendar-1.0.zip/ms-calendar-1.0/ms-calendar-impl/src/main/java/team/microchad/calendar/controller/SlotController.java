package team.microchad.calendar.controller;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import team.microchad.calendar.api.SlotControllerApi;
import team.microchad.calendar.dto.SlotDto;
import team.microchad.calendar.service.ParsingService;
import team.microchad.calendar.service.SlotService;

import java.io.IOException;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class SlotController implements SlotControllerApi {
    private static final String SLOT_STORED = "Slot stored";
    private static final String SLOT_DELETED = "Slot deleted";
    private static final String SLOT_UPDATED = "Slot updated";
    private final SlotService slotService;
    private final ParsingService parsingService;


    @Override
    public ResponseEntity<List<SlotDto>> getAllSlot() {
        return ResponseEntity.ok(slotService.findAll());
    }

    @Override
    public ResponseEntity<SlotDto> getSlotById(Long department, LocalDate date, String time) {
        return ResponseEntity.ok(slotService.findById(Date.valueOf(date), Time.valueOf(time), department));
    }

    @Override
    @SneakyThrows(IOException.class)
    public ResponseEntity<Void> load(Resource body) {
        parsingService.parseSeasonXlsxToSlot(body.getInputStream());
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<String> postSlot(SlotDto slot) {
        slotService.save(slot);
        return ResponseEntity.ok(SLOT_STORED);
    }

    @Override
    public ResponseEntity<String> deleteSlot(Long department, LocalDate date, String time) {
        slotService.delete(Date.valueOf(date), Time.valueOf(time), department);
        return ResponseEntity.ok(SLOT_DELETED);
    }


    @Override
    public ResponseEntity<String> putSlot(SlotDto slot) {
            slotService.update(slot);
        return ResponseEntity.ok(SLOT_UPDATED);
    }

}
