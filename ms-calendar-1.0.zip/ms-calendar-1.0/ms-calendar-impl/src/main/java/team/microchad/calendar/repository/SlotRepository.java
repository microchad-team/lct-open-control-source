package team.microchad.calendar.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import team.microchad.calendar.entity.Department;
import team.microchad.calendar.entity.Slot;
import team.microchad.calendar.entity.SlotId;

import java.util.Date;
import java.util.List;

@Repository
public interface SlotRepository extends CrudRepository<Slot, SlotId> {
    List<Slot> findSlotsByDepartmentAndDateBetweenAndBusinessIdIsNull(Department department, Date date1, Date date2);

    List<Slot> findSlotsByDepartmentAndDateBetweenAndBusinessIdIsNotNull(Department department, Date date1, Date date2);
}