package team.microchad.calendar.service.client;

import org.springframework.cloud.openfeign.FeignClient;
import team.microchad.lk.api.feign.LkApiClient;

@FeignClient(value = "lk")
public interface LkClient extends LkApiClient {

}
