package team.microchad.calendar.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import team.microchad.calendar.entity.ControlType;
import team.microchad.calendar.entity.Department;
import team.microchad.calendar.entity.Slot;
import team.microchad.calendar.entity.Theme;
import team.microchad.calendar.repository.ControlTypeRepository;
import team.microchad.calendar.repository.DepartmentRepository;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import static team.microchad.calendar.util.CellUtils.isCellNotContainsNullOrEmptyDate;
import static team.microchad.calendar.util.CellUtils.isCellNotContainsNullOrEmptyString;

@Service
@Slf4j
@RequiredArgsConstructor
public class ParsingService {
    private static final DateTimeFormatter TIME_FORMATTER4 = DateTimeFormatter.ofPattern("H:mm");
    private static final DateTimeFormatter TIME_FORMATTER5 = DateTimeFormatter.ofPattern("HH:mm");
    private static final String TIME_PERIOD_SEPARATOR = "-";
    public static final String SLOT_BEGINNING = "Слоты";
    private final DepartmentRepository departmentRepository;
    private final ControlTypeRepository controlTypeRepository;

    public List<Slot> parseSeasonXlsxToSlot(InputStream xlsx) throws IOException {
        List<Slot> result = new ArrayList<>();
        Workbook workbook = new XSSFWorkbook(xlsx);
        Iterator<Sheet> it = workbook.sheetIterator();
        it.next();
        while (it.hasNext()) {
            Sheet currentSheet = it.next();
            String title = currentSheet.getRow(0).getCell(0).getStringCellValue();
            Optional<Department> optionalDepartment = departmentRepository.findDepartmentByTitleLikeIgnoreCase("%" + title + "%");
            Department currentDepartment = optionalDepartment.orElseGet(() -> Department.builder().title(title).build());
            if (optionalDepartment.isEmpty()) departmentRepository.save(currentDepartment);
            boolean slotLabelPassed = false;
            int i = 2;
            while (i < currentSheet.getLastRowNum()) {
                if (slotLabelPassed) {
                    parseSlot(currentSheet.getRow(i), 0, currentDepartment).ifPresent(result::add);
                    parseSlot(currentSheet.getRow(i), 3, currentDepartment).ifPresent(result::add);
                    parseSlot(currentSheet.getRow(i), 6, currentDepartment).ifPresent(result::add);
                } else {
                    if (currentSheet.getRow(i).getCell(0) != null &&
                            currentSheet.getRow(i).getCell(0).getCellType() == CellType.STRING)
                        slotLabelPassed = currentSheet.getRow(i).getCell(0).getStringCellValue().contains(SLOT_BEGINNING);
                    if (slotLabelPassed) i++;
                }
                i++;
            }
        }
        return result;
    }

    public List<Theme> parseConsultingThemeXlsx(InputStream xlsx) throws IOException {
        Workbook workbook = new XSSFWorkbook(xlsx);
        Iterator<Sheet> it = workbook.sheetIterator();
        for (ControlType type : parseSheetToControlTypes(it.next()))
            try {
                controlTypeRepository.save(type);
            } catch (Exception e) {
            }
        return parseSheetToTheme(it.next());
    }

    private List<Theme> parseSheetToTheme(Sheet sheet) {
        List<Theme> result = new ArrayList<>();
        String name = "";
        ControlType currentType = new ControlType();
        for (int i = 1; i < sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            Optional<ControlType> optionalType;
            if (isCellNotContainsNullOrEmptyString(row.getCell(2))) name = row.getCell(2).getStringCellValue();
            if (!name.equals(currentType.getName())) {
                log.atInfo().log(name);
                optionalType = controlTypeRepository.findControlTypeByNameLikeIgnoreCase("%" + name + "%");
                if (optionalType.isEmpty()) {
                    log.atInfo().log(row.getCell(1).getStringCellValue());
                    Department department = departmentRepository
                            .findDepartmentByTitleLikeIgnoreCase("%" + row.getCell(1).getStringCellValue() + "%").orElseThrow();
                    currentType = ControlType.builder().department(department).name(name).build();
                    controlTypeRepository.save(currentType);
                } else {
                    currentType = optionalType.get();
                }
            }
            result.add(Theme.builder().controlType(currentType).name(row.getCell(3).getStringCellValue()).build());
        }
        return result;
    }

    private List<ControlType> parseSheetToControlTypes(Sheet sheet) {
        List<ControlType> result = new ArrayList<>();
        Department currentDepartment = Department.builder().title("").build();
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            if (isCellNotContainsNullOrEmptyString(row.getCell(1)) &&
                    !currentDepartment.getTitle().equals(row.getCell(1).getStringCellValue())) {
                String title = row.getCell(1).getStringCellValue();
                Optional<Department> optionalDepartment = departmentRepository.findDepartmentByTitleLikeIgnoreCase("%" + title + "%");
                currentDepartment = optionalDepartment.orElse(Department.builder().title(title).build());
                if (optionalDepartment.isEmpty()) departmentRepository.save(currentDepartment);
            }
            result.add(ControlType.builder()
                    .department(currentDepartment)
                    .name(row.getCell(2).getStringCellValue()).build());
        }
        return result;
    }

    private Optional<Slot> parseSlot(Row row, int i, Department currentDepartment) {
        if (isCellNotContainsNullOrEmptyDate(row.getCell(i)) && row.getCell(i + 1).getCellType() != CellType.NUMERIC) {
            String[] timePeriod = row.getCell(i + 1).getStringCellValue().split(TIME_PERIOD_SEPARATOR);
            Time begin = timePeriod[0].length() == 4 ? Time.valueOf(LocalTime.parse(timePeriod[0], TIME_FORMATTER4)) :
                    Time.valueOf(LocalTime.parse(timePeriod[0], TIME_FORMATTER5));
            Time end = timePeriod[1].length() == 4 ? Time.valueOf(LocalTime.parse(timePeriod[1], TIME_FORMATTER4)) :
                    Time.valueOf(LocalTime.parse(timePeriod[1], TIME_FORMATTER5));
            Slot slot = Slot.builder()
                    .date(new Date(row.getCell(i).getDateCellValue().getTime()))
                    .slotBegin(begin)
                    .slotEnd(end)
                    .isApproved(false)
                    .department(currentDepartment).build();
            return Optional.of(slot);
        }
        return Optional.empty();
    }
}
