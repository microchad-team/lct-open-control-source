package team.microchad.calendar.mapper;

import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import team.microchad.calendar.dto.ControlTypeDto;
import team.microchad.calendar.entity.ControlType;

@Mapper(componentModel = "spring", injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public abstract class ControlTypeMapper {

    @Mapping(target = "department", source = "department.id")
    public abstract ControlTypeDto mapControlTypeToDto(ControlType controlType);
}
