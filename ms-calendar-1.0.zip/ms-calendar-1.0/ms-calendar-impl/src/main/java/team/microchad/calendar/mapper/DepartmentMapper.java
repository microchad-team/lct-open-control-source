package team.microchad.calendar.mapper;

import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import team.microchad.calendar.dto.DepartmentDto;
import team.microchad.calendar.entity.Department;

import java.util.List;

@Mapper(componentModel = "spring", injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public abstract class DepartmentMapper {
    public abstract DepartmentDto departmentToDepartmentDto(Department department);

    public abstract Department departmentDtoToDepartment(DepartmentDto department);

    public abstract List<DepartmentDto> departmentToDepartmentDto(List<Department> departments);

    public abstract List<Department> departmentDtoToDepartment(List<DepartmentDto> department);
}
