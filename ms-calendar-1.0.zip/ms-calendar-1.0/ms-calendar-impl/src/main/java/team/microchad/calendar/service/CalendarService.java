package team.microchad.calendar.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import team.microchad.calendar.dto.CalendarDto;
import team.microchad.calendar.dto.DayDto;
import team.microchad.calendar.dto.SlotDto;
import team.microchad.calendar.entity.Slot;
import team.microchad.calendar.mapper.SlotMapper;
import team.microchad.calendar.repository.DepartmentRepository;
import team.microchad.calendar.repository.SlotRepository;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class CalendarService {
    private final SlotRepository slotRepository;
    private final DepartmentRepository departmentRepository;
    private final SlotMapper slotMapper;

    public CalendarDto findByCriteria(Boolean free, Long department, LocalDate since, LocalDate until) {
        List<Slot> slots;
        if (free)
            slots = slotRepository.findSlotsByDepartmentAndDateBetweenAndBusinessIdIsNull(
                    departmentRepository.findById(department).orElseThrow(),
                    Date.from(since.atStartOfDay(ZoneId.systemDefault()).toInstant()),
                    Date.from(until.atStartOfDay(ZoneId.systemDefault()).toInstant()));
        else
            slots = slotRepository.findSlotsByDepartmentAndDateBetweenAndBusinessIdIsNotNull(
                    departmentRepository.findById(department).orElseThrow(),
                    Date.from(since.atStartOfDay(ZoneId.systemDefault()).toInstant()),
                    Date.from(until.atStartOfDay(ZoneId.systemDefault()).toInstant()));
        Map<String, List<SlotDto>> days = new HashMap<>();
        for (Slot slot : slots) {
            if (days.containsKey(slot.getDate().toString()))
                days.get(slot.getDate().toString()).add(slotMapper.slotToSlotDto(slot));
            else days.put(slot.getDate().toString(), List.of(slotMapper.slotToSlotDto(slot)));
        }
        CalendarDto result = new CalendarDto();
        result.days(days.entrySet().stream().map(x -> {
            DayDto day = new DayDto();
            day.setDay(x.getKey());
            day.setSlots(x.getValue());
            return day;
        }).toList());
        return result;
    }
}
