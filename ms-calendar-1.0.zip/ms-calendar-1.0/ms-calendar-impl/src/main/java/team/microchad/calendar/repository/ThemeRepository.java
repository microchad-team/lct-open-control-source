package team.microchad.calendar.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import team.microchad.calendar.entity.ControlType;
import team.microchad.calendar.entity.Theme;

import java.util.List;

@Repository
public interface ThemeRepository extends CrudRepository<Theme, Long> {
    List<Theme> findAllByControlType(ControlType controlType);
}
