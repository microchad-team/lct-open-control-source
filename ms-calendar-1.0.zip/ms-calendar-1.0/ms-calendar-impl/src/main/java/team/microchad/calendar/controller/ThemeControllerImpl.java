package team.microchad.calendar.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import team.microchad.calendar.api.ThemeApi;
import team.microchad.calendar.dto.ThemeDto;
import team.microchad.calendar.entity.ControlType;
import team.microchad.calendar.mapper.ThemeMapper;
import team.microchad.calendar.repository.ControlTypeRepository;
import team.microchad.calendar.repository.ThemeRepository;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class ThemeControllerImpl implements ThemeApi {
    private final ThemeRepository themeRepository;
    private final ControlTypeRepository controlTypeRepository;
    private final ThemeMapper themeMapper;

    @Override
    public ResponseEntity<List<ThemeDto>> getByType(Long controlTypeId) {
        ControlType controlType = controlTypeRepository.findById(controlTypeId).orElseThrow();
        return ResponseEntity.ok(themeRepository.findAllByControlType(controlType).stream()
                .map(themeMapper::mapThemeToDto).toList());
    }
}
