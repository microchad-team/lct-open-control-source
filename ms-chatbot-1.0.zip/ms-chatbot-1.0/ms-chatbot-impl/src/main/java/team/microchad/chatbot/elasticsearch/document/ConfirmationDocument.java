package team.microchad.chatbot.elasticsearch.document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ConfirmationDocument {
    private String name;
    private String organizations;
    private String interDepPossibility;
    private String period;
}
