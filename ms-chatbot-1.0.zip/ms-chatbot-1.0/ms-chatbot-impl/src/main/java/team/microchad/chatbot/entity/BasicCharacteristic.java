package team.microchad.chatbot.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@AllArgsConstructor
@Builder
@NoArgsConstructor
@Table(name = "basic_characteristic")
public class BasicCharacteristic {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long id;
    @Column
    String title;
    @Column
    int selectRatio;
    @OneToMany(mappedBy = "characteristic")
    List<BasicQuestion> basicQuestions;
}
