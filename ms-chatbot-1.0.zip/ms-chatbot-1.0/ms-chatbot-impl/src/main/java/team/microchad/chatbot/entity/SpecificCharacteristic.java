package team.microchad.chatbot.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@AllArgsConstructor
@Builder
@NoArgsConstructor
@Table(name = "specific_characteristic")
public class SpecificCharacteristic {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long id;
    @Column
    String title;
    @ManyToOne
    @JoinColumn(name = "basic_question")
    BasicQuestion basicQuestion;
    @Column
    int selectRatio;
    @OneToMany(mappedBy = "characteristic")
    List<SpecificQuestion> specificQuestions;
}
