package team.microchad.chatbot.elasticsearch.service;

import team.microchad.chatbot.dto.MessageRequest;
import team.microchad.chatbot.dto.MessageResponse;
import team.microchad.chatbot.elasticsearch.document.Requirement;

import java.util.List;

public interface RequirementService {
    void createRequirementIndexBulk(final List<Requirement> requirementList);

    void createRequirementIndex(Requirement requirement);

    team.microchad.chatbot.dto.Requirement findById(String id);

    MessageResponse assembleRequirementsFromMessage(MessageRequest request);
}
