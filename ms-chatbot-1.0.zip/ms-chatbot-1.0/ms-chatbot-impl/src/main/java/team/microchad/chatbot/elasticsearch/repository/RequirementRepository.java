package team.microchad.chatbot.elasticsearch.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.annotations.Query;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;
import team.microchad.chatbot.elasticsearch.document.Requirement;

@Repository
public interface RequirementRepository extends ElasticsearchRepository<Requirement, String> {
    @Query("{\n" +
            "    \"match\": {\n" +
            "      \"requirementName\": {\n" +
            "        \"query\": \"?0\"\n" +
            "      }\n" +
            "    }\n" +
            "  }\n")
    Page<Requirement> findRequirementByMessage(String message, Pageable pageable);
}
