package team.microchad.chatbot.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import team.microchad.chatbot.elasticsearch.document.*;
import team.microchad.chatbot.elasticsearch.repository.RequirementRepository;
import team.microchad.chatbot.entity.BasicCharacteristic;
import team.microchad.chatbot.entity.BasicQuestion;
import team.microchad.chatbot.entity.SpecificCharacteristic;
import team.microchad.chatbot.entity.SpecificQuestion;
import team.microchad.chatbot.repository.BasicQuestionRepository;
import team.microchad.chatbot.repository.CharacteristicRepository;
import team.microchad.chatbot.repository.SpecificCharacteristicRepository;
import team.microchad.chatbot.repository.SpecificQuestionRepository;
import team.microchad.chatbot.service.ParsingService;
import team.microchad.chatbot.util.Tuple;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static team.microchad.chatbot.util.CellUtils.isCellNotContainsNullOrEmptyString;

@Service
@Slf4j
@RequiredArgsConstructor
public class ParsingServiceImpl implements ParsingService {
    private final SpecificQuestionRepository specificQuestionRepository;
    private final SpecificCharacteristicRepository specificCharacteristicRepository;
    private final BasicQuestionRepository basicQuestionRepository;
    private final CharacteristicRepository characteristicRepository;
    private final RequirementRepository requirementRepository;

    @Override
    public void loadDocument(String departmentName, InputStream stream) {
        var parsingResult = parseXlsx(stream);
        parsingResult.forEach(requirement -> {
            requirement.setDepartment(departmentName);
        });
        requirementRepository.saveAll(parsingResult);
    }

    @SneakyThrows
    private List<Requirement> parseXlsx(InputStream xlsx) {
        Workbook workbook = new XSSFWorkbook(xlsx);
        Sheet sheet = workbook.getSheetAt(0);
        List<Requirement> result = new ArrayList<>();
        String currentBasicRequirement = "";
        Requirement currentRequirement = null;
        Confirmation currentConfirmation = null;
        Responsibility currentResponsibility = null;
        log.info("Last row num = " + sheet.getLastRowNum());
        for (int i = 2; i < sheet.getLastRowNum(); i++) {
            var row = sheet.getRow(i);
            if (isCellNotContainsNullOrEmptyString(row.getCell(2))) {
                currentBasicRequirement = row.getCell(2).getStringCellValue();
                continue;
            }
            if (isCellNotContainsNullOrEmptyString(row.getCell(3))) {
                currentRequirement = createNewRequirementAndGetBasicInfo(currentBasicRequirement, row);
                createQuestions(row, currentRequirement);
                result.add(currentRequirement);
            }
            if (isCellNotContainsNullOrEmptyString(row.getCell(5))) {
                LegalAct legalAct = getLegalAct(row);
                assert currentRequirement != null;
                currentRequirement
                        .getLegalActs()
                        .add(legalAct);
            }

            if (isCellNotContainsNullOrEmptyString(row.getCell(8))) {
                currentConfirmation = new Confirmation();
                currentConfirmation.setMethod(Integer.parseInt(row.getCell(8).getStringCellValue()));
                currentConfirmation.setConfirmationDocuments(new ArrayList<>());
                assert currentRequirement != null;
                currentRequirement
                        .getConfirmations()
                        .add(currentConfirmation);
            }

            if (isCellNotContainsNullOrEmptyString(row.getCell(9))) {
                assert currentConfirmation != null;
                currentConfirmation
                        .getConfirmationDocuments()
                        .add(getConfirmationDocument(row));

                row.getCell(9).getStringCellValue();
            }

            if (isCellNotContainsNullOrEmptyString(row.getCell(13))) {
                if (currentResponsibility != null) {
                    assert currentRequirement != null;
                    currentRequirement.getResponsibilities().add(currentResponsibility);
                }
                currentResponsibility = createResponsibility(row);
            }

            if (isCellNotContainsNullOrEmptyString(row.getCell(14))) {
                assert currentRequirement != null;
                assert currentResponsibility != null;
                currentResponsibility.getSubjects().add(createNewSubjectOfResponse(row));
            }
        }
        return result;
    }

    private Responsibility createResponsibility(Row row) {
        return Responsibility.builder()
                .type(row.getCell(13).getStringCellValue())
                .kind(row.getCell(17).getStringCellValue())
                .legalAct(row.getCell(18).getStringCellValue())
                .authority(row.getCell(19).getStringCellValue())
                .order(row.getCell(20).getStringCellValue())
                .subjects(new ArrayList<>()).build();
    }

    //I hate ladders
    private void createQuestions(Row row, Requirement requirement) {
        if (isCellNotContainsNullOrEmptyString(row.getCell(23))) {
            BasicCharacteristic characteristic = getBasicCharacteristic(row);
            if (isCellNotContainsNullOrEmptyString(row.getCell(24))) {
                BasicQuestion question = getBasicQuestion(row, characteristic);
                requirement.setGeneralQuestion(question.getId());
                if (isCellNotContainsNullOrEmptyString(row.getCell(25))) {
                    SpecificCharacteristic specCharacteristic = getSpecificCharateristic(row, question);
                    if (isCellNotContainsNullOrEmptyString(row.getCell(26))) {
                        SpecificQuestion specQuestion = getSpecificQuestion(row, specCharacteristic);
                        requirement.setSpecifyingQuestion(specQuestion.getId());
                    }
                }
            }
        }
    }

    private SpecificQuestion getSpecificQuestion(Row row, SpecificCharacteristic specCharacteristic) {
        SpecificQuestion specQuestion;
        var specificDbQuestion = specificQuestionRepository
                .findByQuestionIgnoreCase(row.getCell(26)
                        .getStringCellValue());
        if (specificDbQuestion.isEmpty()) {
            specQuestion = SpecificQuestion.builder()
                    .question(row.getCell(26).getStringCellValue())
                    .characteristic(specCharacteristic)
                    .selectRatio(0)
                    .build();
            specificQuestionRepository.save(specQuestion);
        } else {
            specQuestion = specificDbQuestion.get();
        }
        return specQuestion;
    }

    private SpecificCharacteristic getSpecificCharateristic(Row row, BasicQuestion question) {
        SpecificCharacteristic specCharacteristic;
        var specDbCharacteristic = specificCharacteristicRepository
                .findByTitleIgnoreCase(row.getCell(25)
                        .getStringCellValue());
        if (specDbCharacteristic.isEmpty()) {
            specCharacteristic = SpecificCharacteristic.builder()
                    .basicQuestion(question)
                    .title(row.getCell(25).getStringCellValue())
                    .selectRatio(0)
                    .build();
            specificCharacteristicRepository.save(specCharacteristic);
        } else {
            specCharacteristic = specDbCharacteristic.get();
        }
        return specCharacteristic;
    }

    private BasicQuestion getBasicQuestion(Row row, BasicCharacteristic characteristic) {
        BasicQuestion question;
        var basicDbQuestion = basicQuestionRepository
                .findByQuestionIgnoreCase(row.getCell(24).getStringCellValue());
        if (basicDbQuestion.isEmpty()) {
            question = BasicQuestion.builder()
                    .question(row.getCell(24).getStringCellValue())
                    .selectRatio(0)
                    .characteristic(characteristic)
                    .build();
            basicQuestionRepository.save(question);
        } else {
            question = basicDbQuestion.get();
        }
        return question;
    }

    private BasicCharacteristic getBasicCharacteristic(Row row) {
        var basicDbCharacteristic = characteristicRepository
                .findByTitleIgnoreCase(row.getCell(23).getStringCellValue());
        BasicCharacteristic characteristic;
        if (basicDbCharacteristic.isEmpty()) {
            characteristic = BasicCharacteristic.builder()
                    .title(row.getCell(23).getStringCellValue())
                    .selectRatio(0)
                    .build();
            characteristicRepository.save(characteristic);
        } else {
            characteristic = basicDbCharacteristic.get();
        }
        return characteristic;
    }

    private SubjectOfResponse createNewSubjectOfResponse(Row row) {
        return SubjectOfResponse.builder().subject(row.getCell(14).getStringCellValue())
                .sanction(row.getCell(15).getStringCellValue())
                .size(row.getCell(16).getStringCellValue()).build();
    }

    private ConfirmationDocument getConfirmationDocument(Row row) {
        var confirmationDocument = new ConfirmationDocument();
        if (isCellNotContainsNullOrEmptyString(row.getCell(9))) {
            confirmationDocument.setName(row.getCell(9).getStringCellValue());

        }
        if (isCellNotContainsNullOrEmptyString(row.getCell(10))) {
            confirmationDocument.setOrganizations(row.getCell(10).getStringCellValue());
        }
        if (isCellNotContainsNullOrEmptyString(row.getCell(11))) {
            confirmationDocument.setInterDepPossibility(row.getCell(11).getStringCellValue());
        }
        if (isCellNotContainsNullOrEmptyString(row.getCell(12))) {
            confirmationDocument.setPeriod(row.getCell(12).getStringCellValue());
        }
        return confirmationDocument;
    }

    private Requirement createNewRequirementAndGetBasicInfo(String currentBasicRequirement, Row row) {
        Requirement currentRequirement;
        Tuple<Date, Date> dates = parseDates(row.getCell(7).getStringCellValue());
        currentRequirement = new Requirement();
        currentRequirement.setId(row.getCell(0).getStringCellValue());
        currentRequirement.setBasicRequirement(currentBasicRequirement);
        currentRequirement.setRequirementName(row.getCell(3).getStringCellValue());
        currentRequirement.setType(row.getCell(4).getStringCellValue());
        currentRequirement.setPeriodSince(dates.x);
        currentRequirement.setPeriodUntil(dates.y);
        currentRequirement.setActivityTypes(
                parseActivityTypes(
                        row.getCell(21).getStringCellValue()
                )
        );
        currentRequirement.setLegalActs(new ArrayList<>());
        currentRequirement.setConfirmations(new ArrayList<>());
        currentRequirement.setResponsibilities(new ArrayList<>());

        return currentRequirement;
    }

    private LegalAct getLegalAct(Row row) {
        var legalAct = new LegalAct();
        legalAct.setLegalActName(row.getCell(5).getStringCellValue());
        var dates = parseDates(row.getCell(6).getStringCellValue());
        legalAct.setPeriodSince(dates.x);
        legalAct.setPeriodSince(dates.y);
        return legalAct;
    }

    private List<ActivityType> parseActivityTypes(String inputString) {
        Pattern pattern = Pattern.compile("(\\d{1,2}\\.\\d{1,2}(\\.\\d{1,2})?)\\s(.*?)($|,\\s)");
        Matcher matcher = pattern.matcher(inputString);
        List<ActivityType> activityTypes = new ArrayList<>(5);
        while (matcher.find()) {
            String code = matcher.group(1);
            String title = matcher.group(3);
            ActivityType activityType = new ActivityType();
            activityType.setCode(code);
            activityType.setTitle(title);
            activityTypes.add(activityType);
        }

        return activityTypes;
    }

    @SneakyThrows
    public Tuple<Date, Date> parseDates(String inputString) {
        String[] elements = inputString.split(" - ");
        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");

        Date startDate = formatter.parse(elements[0].substring(2));
        Date endDate = elements.length > 1 ? formatter.parse(elements[0].substring(2)) : new Date(Long.MAX_VALUE);
        return new Tuple<>(startDate, endDate);
    }


}
