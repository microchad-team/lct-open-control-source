package team.microchad.chatbot.repository;

import org.springframework.data.repository.CrudRepository;
import team.microchad.chatbot.entity.BasicCharacteristic;

import java.util.Optional;

public interface CharacteristicRepository extends CrudRepository<BasicCharacteristic, Long> {
    Optional<BasicCharacteristic> findByTitleIgnoreCase(String title);
    boolean existsByTitleIgnoreCase(String title);

}
