package team.microchad.chatbot.mapper;

import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import team.microchad.chatbot.dto.LegalAct;

@Mapper(componentModel = "spring", injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public abstract class LegalActMapper {

    public abstract LegalAct mapLegalActToDto(team.microchad.chatbot.elasticsearch.document.LegalAct legalAct);
}
