package team.microchad.chatbot.repository;

import org.springframework.data.repository.CrudRepository;
import team.microchad.chatbot.entity.SpecificCharacteristic;

import java.util.Optional;

public interface SpecificCharacteristicRepository extends CrudRepository<SpecificCharacteristic, Long> {
    Optional<SpecificCharacteristic> findByTitleIgnoreCase(String title);
}