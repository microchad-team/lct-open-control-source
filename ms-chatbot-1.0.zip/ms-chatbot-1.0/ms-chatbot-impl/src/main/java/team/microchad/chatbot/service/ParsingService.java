package team.microchad.chatbot.service;

import team.microchad.chatbot.elasticsearch.document.Requirement;
import team.microchad.chatbot.entity.BasicQuestion;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

public interface ParsingService {
    void loadDocument(String departmentName, InputStream stream);
}
