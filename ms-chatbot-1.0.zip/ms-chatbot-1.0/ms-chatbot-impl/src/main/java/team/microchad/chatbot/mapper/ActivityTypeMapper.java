package team.microchad.chatbot.mapper;

import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import team.microchad.chatbot.dto.ActivityType;

@Mapper(componentModel = "spring", injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public abstract class ActivityTypeMapper {
    public abstract ActivityType mapActivityTypeToDto(team.microchad.chatbot.elasticsearch.document.ActivityType activityType);
}
