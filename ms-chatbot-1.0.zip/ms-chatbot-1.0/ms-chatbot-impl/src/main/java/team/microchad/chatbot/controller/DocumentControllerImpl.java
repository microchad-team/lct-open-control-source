package team.microchad.chatbot.controller;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import team.microchad.chatbot.api.RequirementApi;
import team.microchad.chatbot.service.ParsingService;

import java.io.FileInputStream;
import java.nio.file.Path;

@Slf4j
@RequiredArgsConstructor
@RestController
public class DocumentControllerImpl implements RequirementApi {

    final ParsingService parsingService;
    @Override
    @SneakyThrows
    public ResponseEntity<Void> load(String department, Resource body) {
        parsingService.loadDocument(department, body.getInputStream());
        return new ResponseEntity<>(HttpStatusCode.valueOf(200));
    }
}
