package team.microchad.chatbot.elasticsearch.document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LegalAct {
    private String legalActName;
    private Date periodSince;
    private Date periodUntil;
}
