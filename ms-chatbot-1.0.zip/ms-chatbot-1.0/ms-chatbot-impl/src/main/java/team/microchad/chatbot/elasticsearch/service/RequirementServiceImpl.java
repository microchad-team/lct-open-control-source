package team.microchad.chatbot.elasticsearch.service;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import team.microchad.chatbot.dto.Action;
import team.microchad.chatbot.dto.Button;
import team.microchad.chatbot.dto.MessageRequest;
import team.microchad.chatbot.dto.MessageResponse;
import team.microchad.chatbot.elasticsearch.document.Requirement;
import team.microchad.chatbot.elasticsearch.repository.RequirementRepository;
import team.microchad.chatbot.mapper.RequirementMapper;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class RequirementServiceImpl implements RequirementService {
    private final RequirementRepository repository;
    private final RequirementMapper requirementMapper;

    @Override
    public void createRequirementIndexBulk(final List<Requirement> requirementList) {
        repository.saveAll(requirementList);
    }

    @Override
    public void createRequirementIndex(final Requirement requirement) {
        repository.save(requirement);
    }

    @Override
    public team.microchad.chatbot.dto.Requirement findById(String id) {
        return requirementMapper.mapRequirementToDto(repository.findById(id).orElseThrow());
    }

    @Override
    public MessageResponse assembleRequirementsFromMessage(MessageRequest request) {
        MessageResponse response = new MessageResponse();
        List<Button> buttons = new ArrayList<>();
        int i = 0;
        for (Requirement requirement : repository.findRequirementByMessage(request.getMessage(),
                PageRequest.of(0, 10))) {
            Action action = new Action();
            action.setActionType(0);
            action.setAction("/api/v1/requirement?id=" + requirement.getId());
            Button button = new Button();
            button.buttonId(i++);
            button.action(action);
            button.text(requirement.getRequirementName());
            buttons.add(button);
        }
        response.setButtons(buttons);
        response.setMessage("Вот что удалось найти!");
        return response;
    }
}
