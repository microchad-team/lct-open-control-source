package team.microchad.chatbot.mapper;

import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import team.microchad.chatbot.dto.Responsibility;

@Mapper(componentModel = "spring", injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public abstract class ResponsibilityMapper {
    public abstract Responsibility mapResponsibilityToDto(team.microchad.chatbot.elasticsearch.document.Responsibility responsibility);
}
