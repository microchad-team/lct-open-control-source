package team.microchad.chatbot.entity;


import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.elasticsearch.annotations.Field;

import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@Builder
@Entity
@AllArgsConstructor
@Table(name = "basic_question")
public class BasicQuestion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long id;
    @ManyToOne
    @JoinColumn(name = "characteristic")
    BasicCharacteristic characteristic;
    @Field
    String question;
    @Field
    int selectRatio;
    @OneToMany(mappedBy = "basicQuestion")
    List<SpecificCharacteristic> specificCharacteristic;
}
