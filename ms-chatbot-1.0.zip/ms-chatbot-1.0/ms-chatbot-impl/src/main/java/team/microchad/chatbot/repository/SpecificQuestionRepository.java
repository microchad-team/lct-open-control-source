package team.microchad.chatbot.repository;

import org.springframework.data.repository.CrudRepository;
import team.microchad.chatbot.entity.SpecificQuestion;

import java.util.Optional;

public interface SpecificQuestionRepository extends CrudRepository<SpecificQuestion, Long> {
    Optional<SpecificQuestion> findByQuestionIgnoreCase(String question);
}