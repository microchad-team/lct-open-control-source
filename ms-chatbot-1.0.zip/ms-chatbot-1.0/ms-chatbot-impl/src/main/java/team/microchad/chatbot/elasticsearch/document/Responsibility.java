package team.microchad.chatbot.elasticsearch.document;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class Responsibility {
    public String type;
    public List<SubjectOfResponse> subjects;
    public String kind;
    public String legalAct;
    public String authority;
    public String order;
}
