package team.microchad.chatbot.util;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;

public class CellUtils {
    public static boolean isCellNotContainsNullOrEmptyString(Cell cell) {
        return cell != null
                && cell.getCellType() != CellType.BLANK
                && !cell.getStringCellValue().isEmpty();
    }
}
