package team.microchad.chatbot.mapper;

import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import team.microchad.chatbot.dto.Confirmation;

@Mapper(componentModel = "spring", injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public abstract class ConfirmationMapper {

    public abstract Confirmation mapConfirmationToDto(team.microchad.chatbot.elasticsearch.document.Confirmation confirmation);
}
