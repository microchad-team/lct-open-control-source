package team.microchad.chatbot.repository;

import org.springframework.data.repository.CrudRepository;
import team.microchad.chatbot.entity.BasicQuestion;

import java.util.Optional;

public interface BasicQuestionRepository extends CrudRepository<BasicQuestion, Long> {
    Optional<BasicQuestion> findByQuestionIgnoreCase(String question);
}