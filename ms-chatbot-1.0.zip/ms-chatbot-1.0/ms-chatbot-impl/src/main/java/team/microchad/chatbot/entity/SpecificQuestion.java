package team.microchad.chatbot.entity;


import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.elasticsearch.annotations.Field;

@Setter
@Getter
@NoArgsConstructor
@Builder
@Entity
@AllArgsConstructor
@Table(name = "specific_question")
public class SpecificQuestion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long id;
    @ManyToOne
    @JoinColumn(name = "characteristic")
    SpecificCharacteristic characteristic;
    @Field
    String question;
    @Field
    int selectRatio;
}
