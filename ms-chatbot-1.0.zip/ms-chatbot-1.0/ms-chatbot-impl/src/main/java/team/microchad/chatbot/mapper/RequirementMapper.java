package team.microchad.chatbot.mapper;

import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import team.microchad.chatbot.dto.Requirement;

@Mapper(uses = {LegalActMapper.class, ConfirmationMapper.class, ActivityTypeMapper.class, RequirementMapper.class},
        componentModel = "spring", injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public abstract class RequirementMapper {

    public abstract Requirement mapRequirementToDto(team.microchad.chatbot.elasticsearch.document.Requirement requirement);
}
