package team.microchad.chatbot.elasticsearch.document;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SubjectOfResponse {
    public String subject;
    public String sanction;
    public String size;
}
