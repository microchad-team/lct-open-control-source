package team.microchad.chatbot.elasticsearch.config;

import co.elastic.clients.transport.TransportUtils;
import lombok.SneakyThrows;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.server.Ssl;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.elasticsearch.client.ClientConfiguration;
import org.springframework.data.elasticsearch.client.elc.ElasticsearchConfiguration;
import org.springframework.data.elasticsearch.repository.config.EnableElasticsearchRepositories;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.File;
import java.security.cert.X509Certificate;

@Configuration
@EnableElasticsearchRepositories(basePackages = "team.microchad.chatbot.elasticsearch.repository")
@ComponentScan(basePackages = {"team.microchad.chatbot.elasticsearch"})
public class ElasticSearchClientConfig extends ElasticsearchConfiguration {

    @Value("${ELASTIC_HOST}")
    private String elasticHost;

    @Value("${ELASTIC_PORT}")
    private int elasticPort;

    @Value("${ELASTIC_LOGIN}")
    private String elasticLogin;

    @Value("${ELASTIC_PASSWORD}")
    private String elasticPassword;

    /*@Value("${ELASTIC_FINGERPRINT}")
    private String fingerprint;*/



    @Override
    @SneakyThrows
    public ClientConfiguration clientConfiguration() {
        BasicCredentialsProvider credsProv = new BasicCredentialsProvider();
        credsProv.setCredentials(
                AuthScope.ANY, new UsernamePasswordCredentials(elasticLogin, elasticPassword)
        );
        return ClientConfiguration
                .builder()
                .connectedTo(elasticHost + ":" + elasticPort)
                .withBasicAuth(elasticLogin, elasticPassword)
                .build();
    }


}
