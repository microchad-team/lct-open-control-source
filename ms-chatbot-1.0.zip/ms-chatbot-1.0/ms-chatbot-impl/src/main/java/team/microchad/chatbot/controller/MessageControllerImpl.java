package team.microchad.chatbot.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import team.microchad.chatbot.api.MessageApi;
import team.microchad.chatbot.dto.MessageRequest;
import team.microchad.chatbot.dto.MessageResponse;
import team.microchad.chatbot.dto.Requirement;
import team.microchad.chatbot.elasticsearch.service.RequirementService;

@RestController
@RequiredArgsConstructor
public class MessageControllerImpl implements MessageApi {
    private final RequirementService requirementService;

    @Override
    public ResponseEntity<Requirement> getRequirement(String id) {
        return ResponseEntity.ok(requirementService.findById(id));
    }

    @Override
    public ResponseEntity<MessageResponse> getSelection(String selectedId, String menuType, Integer page, Integer size) {
        return null;
    }

    @Override
    public ResponseEntity<MessageResponse> init() {
        return null;
    }

    @Override
    public ResponseEntity<MessageResponse> processMessage(MessageRequest messageRequest) {
        return ResponseEntity.ok(requirementService.assembleRequirementsFromMessage(messageRequest));
    }
}
