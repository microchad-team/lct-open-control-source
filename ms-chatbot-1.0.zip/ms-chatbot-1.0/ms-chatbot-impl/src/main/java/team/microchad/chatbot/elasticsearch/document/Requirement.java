package team.microchad.chatbot.elasticsearch.document;

import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.util.Date;
import java.util.List;

@Builder
@Document(indexName = "requirements")
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Requirement {
    @Id
    private String id;

    @Field(type = FieldType.Text, name = "department")
    private String department;

    @Field(type = FieldType.Text, name = "basicRequirement")
    private String basicRequirement;

    @Field(type = FieldType.Text, name = "requirementName")
    private String requirementName;

    @Field(type = FieldType.Integer, name = "type")
    private String type;

    @Field(type = FieldType.Nested, name = "legalAct")
    private List<LegalAct> legalActs;

    @Field(type = FieldType.Date, name = "periodSince")
    private Date periodSince;

    @Field(type = FieldType.Date, name = "periodSince")
    private Date periodUntil;

    @Field(type = FieldType.Nested, name = "confirmations")
    private List<Confirmation> confirmations;

    @Field(type = FieldType.Nested, name = "activityTypes")
    private List<ActivityType> activityTypes;

    @Field(type = FieldType.Nested, name = "responsibilities")
    private List<Responsibility> responsibilities;

    @Field(type = FieldType.Long, name = "generalQuestion")
    private long generalQuestion;

    @Field(type = FieldType.Long, name = "specifyingQuestion")
    private long specifyingQuestion;
}
